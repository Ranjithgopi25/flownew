from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from fastapi.responses import StreamingResponse
from typing import Optional, Union, Dict, Any
from app.core.deps import get_llm_service, create_chat_history_context
from app.infrastructure.llm.llm_service import LLMService
from app.features.ddc.agents.sanitization_agent import SanitizationAgent
from app.features.ddc.services.sanitization.utils import SanitizationService
from app.features.ddc.services.slide_creation_service import PlusDocsClient
import logging
import uuid
import asyncio
from datetime import datetime, timedelta
from fastapi.responses import JSONResponse, Response
import json
from app.core.config import config

router = APIRouter()
logger = logging.getLogger(__name__)

# Temporary storage for conversation state
# In production, use Redis or a database
conversation_storage: Dict[str, Dict[str, Any]] = {}


def cleanup_old_conversations():
    """Remove conversations older than 1 hour"""
    cutoff = datetime.now() - timedelta(hours=2)
    to_delete = [
        conv_id for conv_id, data in conversation_storage.items()
        if data.get('timestamp', datetime.now()) < cutoff
    ]
    for conv_id in to_delete:
        del conversation_storage[conv_id]
        logger.info(f"[Cleanup] Removed conversation: {conv_id}")


@router.post("")
async def ddc_chat_agent(
    message: str = Form(...),
    conversation_id: Optional[str] = Form(None),
    file: Optional[UploadFile] = File(None),
    user_id: Optional[str] = Form(None),
    session_id: Optional[str] = Form(None),
    source: Optional[str] = Form(None),
    llm_service: LLMService = Depends(get_llm_service)
):
    """DDC Chat Agent: Conversational interface for DDC workflows"""
    try:
        cleanup_old_conversations()
        
        # Use provided conversation_id or generate new one
        # Frontend should provide session_xxx format
        if not conversation_id or conversation_id == "none":
            conversation_id = f"session_{uuid.uuid4().hex[:8]}"
            logger.info(f"[DDC Chat Agent] Generated new conversation_id: {conversation_id}")
        
        # Use conversation_id as session_id if not provided
        if not session_id:
            session_id = conversation_id
        
        # Initialize chat history context for manual saving (middleware can't capture JSONResponse)
        chat_history = None
        if user_id and session_id:
            chat_history = create_chat_history_context(
                user_id=user_id,
                session_id=session_id,
                source=source or "DDDC"
            )
            logger.info(f"[DDC Chat Agent] Chat history enabled for session {session_id}")
        
        logger.info(f"[DDC Chat Agent] Message: {message} | Conversation: {conversation_id}")
        
        # Initialize conversation storage if new
        if conversation_id not in conversation_storage:
            conversation_storage[conversation_id] = {
                'timestamp': datetime.now(),
                'file_data': None,
                'file_name': None,
                'custom_template_data': None,
                'custom_template_name': None,
                'conversation_history': []
            }
        
        conversation_storage[conversation_id]['timestamp'] = datetime.now()
        
        # Store new file if provided
        if file and file.filename:
            file_data = await file.read()
            conversation_storage[conversation_id]['file_data'] = file_data
            conversation_storage[conversation_id]['file_name'] = file.filename
        
        # Retrieve stored data
        stored_data = conversation_storage[conversation_id]
        file_data = stored_data.get('file_data')
        file_name = stored_data.get('file_name')
        conversation_history = stored_data.get('conversation_history', [])
        
        conversation_history.append({
            'role': 'user',
            'content': message,
            'timestamp': datetime.now().isoformat()
        })

        # Initialize sanitization service
        sanitization_service = SanitizationService(llm_service)
        ppt_service = PlusDocsClient(api_token=config.PLUSDOCS_API_TOKEN)
        
        # Initialize sanitization agent with service
        agent = SanitizationAgent(llm_service, sanitization_service, ppt_service)
        
        # ✅ Process message WITHOUT streaming - collect all results
        result = await agent.process_message_sync(  # ← New sync method
            message=message,
            conversation_id=conversation_id,
            file_data=file_data,
            file_name=file_name,
            conversation_history=conversation_history
        )
        # ← NEW: Add agent response to history AFTER processing
        conversation_history.append({
            'role': 'assistant',
            'content': result.get("message", ""),
            'timestamp': datetime.now().isoformat()
        })
        
        # ← NEW: Update conversation history in storage
        conversation_storage[conversation_id]['conversation_history'] = conversation_history
        
        # Save assistant response to chat history (fire-and-forget)
        assistant_message = result.get("message", "")
        if chat_history and chat_history.enabled and assistant_message:
            asyncio.create_task(
                chat_history.helper.save_assistant_message(assistant_message)
            )
            logger.info(f"[DDC Chat Agent] Saved assistant response to chat history")
        
        # logger.info(f"[DDC Chat Agent] Conversation history length: {len(conversation_history)}")
        # ✅ If file was sanitized, return it like the other router
        if result.get("file_bytes"):
            output_filename = file_name.replace('.pptx', '_sanitized.pptx')
            summary = result.get("summary", {})
            if summary:
                summary_text = ", ".join(
                    f"{k.replace('_', ' ').title()}: {v}"
                    for k, v in summary.items()
                )
            else:
                summary_text = "No sanitization changes were required."

            agent_message = (
                "Sanitization completed successfully. "
                f"{summary_text}"
            )

            
            return Response(
                content=result["file_bytes"],
                media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
                headers={
                    "Content-Disposition": f'attachment; filename="{output_filename}"',
                    "X-Agent-Message": agent_message,
                    "X-Conversation-ID": conversation_id,
                    # "X-Sanitization-Summary": json.dumps(result.get("summary", {})),
                    # "X-Sanitization-Plan": json.dumps(result.get("plan", []))
                }
            )
            

        # ✅ If no file, return JSON message only
        return JSONResponse(
            content={
                "message": result.get("message", ""),
                "conversation_id": conversation_id
            },
            headers={
                "X-Conversation-ID": conversation_id
            }
        )
        
    except Exception as e:
        logger.error(f"[DDC Chat Agent] Error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))
    