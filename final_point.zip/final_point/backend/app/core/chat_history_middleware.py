"""
Chat History Middleware for FastAPI Routers
=============================================
Automatically intercepts requests/responses and saves conversations to chat history.
Handles SSE streaming responses transparently without modifying endpoint logic.

Supports two modes:
1. Quick Chat: User message + assistant response (from body parameters)
2. Guided Journey: Assistant response only as first message (from query parameters)
"""
from fastapi import Request, Response
from fastapi.responses import StreamingResponse
from starlette.responses import StreamingResponse as StarletteStreamingResponse
from starlette.middleware.base import BaseHTTPMiddleware
import logging
import json
import uuid
import jwt
import time
from typing import Optional
from app.core.deps import create_chat_history_context
import asyncio

logger = logging.getLogger(__name__)

# Guided journey endpoint patterns (endpoints that generate content without user messages)
GUIDED_JOURNEY_PATTERNS = [
    # Thought Leadership / DocStudio endpoints
    "/api/v1/tl/draft-content",
    "/api/v1/tl/edit-content",
    "/api/v1/tl/refine-content",
    "/api/v1/tl/conduct-research",
    "/api/v1/tl/format-translator",
    "/api/v1/tl/generate-podcast",
    "/api/v1/tl/update-section",
    
    # Market Intelligence endpoints
    "/api/v1/tl/research-with-materials",
    "/api/v1/tl/prep-client-meeting",
    "/api/v1/tl/pov",
    "/api/v1/tl/proposal_insights",
    "/api/v1/tl/industry_insights",
    
    # DDC endpoints
    "/api/v1/ddc/slide-creation",
    "/api/v1/ddc/sanitization",
    "/api/v1/ddc/phoenix",
]


class ChatHistoryMiddleware(BaseHTTPMiddleware):
    """
    Middleware that automatically captures and stores chat conversations.
    
    Features:
    - Detects guided journey endpoints and saves assistant responses
    - Extracts user_id from JWT tokens automatically
    - Generates session_id matching frontend format
    - Saves user messages before processing
    - Wraps streaming responses to capture and parse SSE format
    - Accumulates content chunks and saves assistant response
    - Non-breaking: gracefully handles missing parameters
    - Zero latency: Uses fire-and-forget async pattern
    """
    
    def _extract_user_from_jwt(self, request: Request) -> Optional[str]:
        """Extract user email from JWT token in Authorization header"""
        try:
            auth_header = request.headers.get("authorization") or request.headers.get("Authorization")
            if not auth_header or not auth_header.startswith("Bearer "):
                return None
            
            token = auth_header.split(" ")[1]
            # Decode without verification to extract email (validation already done by auth middleware)
            decoded = jwt.decode(token, options={"verify_signature": False})
            
            # Try different JWT claim fields for email
            user_email = decoded.get("preferred_username") or decoded.get("email") or decoded.get("upn")
            
            if user_email:
                logger.info(f"[Guided Journey] Extracted user email from JWT: {user_email}")
                return user_email
            
        except Exception as e:
            logger.warning(f"[Guided Journey] Failed to extract user from JWT: {e}")
        
        return None
    
    async def dispatch(self, request: Request, call_next):
        """Intercept request/response to save chat history"""
        
        # Skip health checks and static files
        if request.url.path in ("/health", "/metrics", "/docs", "/openapi.json", "/redoc"):
            return await call_next(request)
        
        # Only process POST requests (chat endpoints)
        if request.method != "POST":
            return await call_next(request)
        
        # Check if this is a guided journey endpoint
        is_guided_journey = any(pattern in str(request.url.path) for pattern in GUIDED_JOURNEY_PATTERNS)
        
        # Extract parameters from query string for guided journey endpoints
        if is_guided_journey:
            user_id = request.query_params.get("user_id")
            session_id = request.query_params.get("session_id")
            source = request.query_params.get("source", "Cortex")
            
            # If user_id not in query params, extract from JWT token
            if not user_id:
                user_id = self._extract_user_from_jwt(request)
            
            # If user_id available (from query params or JWT), enable guided journey chat history
            if user_id:
                # Generate session_id if not provided (match frontend format: session_{timestamp}_{random})
                if not session_id:
                    timestamp = int(time.time() * 1000)  # milliseconds
                    random_suffix = str(uuid.uuid4().hex[:9])  # 9 characters to match frontend
                    session_id = f"session_{timestamp}_{random_suffix}"
                    logger.info(f"[Guided Journey] Generated session_id: {session_id}")
                
                logger.info(f"[Guided Journey] Detected: {request.url.path}, user_id={user_id}, session_id={session_id}, source={source}")
                
                # Create chat history context for guided journey
                chat_history = create_chat_history_context(
                    user_id=user_id,
                    session_id=session_id,
                    source=source
                )
                
                if chat_history.enabled:
                    # Process request
                    response = await call_next(request)
                    
                    # Check if this is a streaming response
                    response_class_name = type(response).__name__
                    is_streaming = response_class_name in ("StreamingResponse", "_StreamingResponse") or hasattr(response, "body_iterator")
                    
                    logger.info(f"[Guided Journey] Response type: {response_class_name}, is streaming: {is_streaming}")
                    
                    # Wrap streaming response to capture as first assistant message
                    if is_streaming:
                        logger.info(f"[Guided Journey] Wrapping response for session {session_id}")
                        wrapped_response = self._wrap_streaming_response(response, chat_history, is_guided_journey=True)
                        # Add session_id to response headers so frontend can read it
                        wrapped_response.headers["X-Session-Id"] = session_id
                        return wrapped_response
                    
                    # For non-streaming responses, also add session_id header
                    response.headers["X-Session-Id"] = session_id
                    return response
        
        # Standard quick chat flow
        # Read request body to extract chat history parameters
        body = await request.body()
        content_type = request.headers.get("content-type", "")
        chat_params = await self._extract_chat_params(body, content_type, request)
        
        # Re-create request with body (since we consumed it)
        request._body = body
        
        # If no chat params but this is a known chat endpoint, log warning
        if not chat_params:
            if "/ddc_chat_agent" in str(request.url) or "/tl_chat_agent" in str(request.url) or "/mi_chat_agent" in str(request.url):
                logger.warning(f"[Chat History Middleware] Chat endpoint detected but missing user_id/session_id: {request.url.path}")
            return await call_next(request)
        
        # Initialize chat history context
        chat_history = create_chat_history_context(
            user_id=chat_params.get("user_id"),
            session_id=chat_params.get("session_id"),
            source=chat_params.get("source", "Cortex")
        )
        
        # If chat history disabled, skip
        if not chat_history.enabled:
            return await call_next(request)
        
        # Save user message
        user_message = chat_params.get("user_message")
        if user_message:
            asyncio.create_task(
                self._save_user_message(chat_history, user_message)
            )
        
        # Process request
        response = await call_next(request)
        
        # Check if this is a streaming response by class name (handles internal _StreamingResponse)
        response_class_name = type(response).__name__
        is_streaming = response_class_name in ("StreamingResponse", "_StreamingResponse") or hasattr(response, "body_iterator")
        
        logger.info(f"[Chat History Middleware] Response type: {response_class_name}, is streaming: {is_streaming}")
        
        # Wrap streaming responses to capture assistant response
        if is_streaming:
            logger.info(f"[Chat History Middleware] Wrapping StreamingResponse for session {chat_params.get('session_id')}")
            return self._wrap_streaming_response(response, chat_history)
        
        # Non-streaming responses (e.g., DDC JSONResponse) are handled by endpoints themselves
        # since middleware cannot intercept their response body without breaking the response
        
        return response
    
    async def _extract_chat_params(self, body: bytes, content_type: str, request: Request) -> Optional[dict]:
        """Extract chat history parameters from request body (JSON or Form data)"""
        try:
            data = {}
            
            # Handle JSON requests
            if "application/json" in content_type:
                data = json.loads(body)
            
            # Handle Form data (multipart/form-data or application/x-www-form-urlencoded)
            elif "multipart/form-data" in content_type or "application/x-www-form-urlencoded" in content_type:
                # For form data, try to get it from request.form()
                # Note: We can't call request.form() here because body is already consumed
                # So we parse form data manually
                try:
                    form = await request.form()
                    data = dict(form)
                    logger.debug(f"[Chat History Middleware] Parsed form data: {list(data.keys())}")
                except Exception as e:
                    logger.debug(f"[Chat History Middleware] Could not parse form data: {e}")
                    return None
            else:
                # Try JSON as fallback
                try:
                    data = json.loads(body)
                except:
                    return None
            
            # Extract parameters
            user_id = data.get("user_id")
            session_id = data.get("session_id")
            source = data.get("source")
            
            # Skip if no user_id or session_id
            if not user_id or not session_id:
                logger.debug(f"[Chat History Middleware] Missing user_id or session_id in request")
                return None
            
            # Extract user message from various formats
            user_message = None
            
            # Format 1: messages array with role/content (JSON format)
            if "messages" in data and isinstance(data["messages"], list):
                for msg in reversed(data["messages"]):
                    if isinstance(msg, dict) and msg.get("role") == "user":
                        user_message = msg.get("content")
                        break
            
            # Format 2: direct content field
            elif "content" in data:
                user_message = data["content"]
            
            # Format 3: query or prompt field
            elif "query" in data:
                user_message = data["query"]
            elif "prompt" in data:
                user_message = data["prompt"]
            
            # Format 4: DDC form data - "message" field
            elif "message" in data:
                user_message = data["message"]
            
            return {
                "user_id": user_id,
                "session_id": session_id,
                "source": source,
                "user_message": user_message
            }
        
        except Exception as e:
            logger.debug(f"[Chat History Middleware] Could not parse request body: {e}")
            return None
    
    async def _save_user_message(self, chat_history, message: str):
        """Save user message (fire-and-forget)"""
        try:
            await chat_history.helper.save_user_message(message)
            logger.info(f"[Chat History Middleware] Saved user message")
        except Exception as e:
            logger.error(f"[Chat History Middleware] Error saving user message: {e}")
    
    def _wrap_streaming_response(self, response: StreamingResponse, chat_history, is_guided_journey: bool = False) -> StreamingResponse:
        """Wrap streaming response to capture and parse SSE content"""
        
        logger.info(f"[Chat History Middleware] _wrap_streaming_response called, chat_history.enabled={chat_history.enabled}, is_guided_journey={is_guided_journey}")
        
        async def stream_with_history():
            """
            Generator that:
            1. Yields chunks to frontend (preserves streaming)
            2. Parses SSE format to extract content
            3. Accumulates full response
            4. Saves to database after streaming completes
            """
            full_response = ""
            chunk_count = 0
            
            try:
                logger.info(f"[Chat History Middleware] Starting to iterate over response.body_iterator")
                async for chunk in response.body_iterator:
                    # Yield original chunk to frontend first
                    yield chunk
                    chunk_count += 1
                    
                    # Parse chunk to accumulate content
                    chunk_text = chunk.decode('utf-8') if isinstance(chunk, bytes) else chunk
                    
                    # SSE format: "data: {"type": "content", "content": "text"}\n\n"
                    if chunk_text.startswith("data: "):
                        try:
                            # Remove "data: " prefix and parse JSON
                            json_str = chunk_text[6:].strip()
                            
                            # Skip empty lines
                            if not json_str:
                                continue
                            
                            data = json.loads(json_str)
                            
                            # Only accumulate content chunks (not metadata or done signals)
                            if data.get("type") == "content" and "content" in data:
                                full_response += data["content"]
                        
                        except json.JSONDecodeError:
                            # Not JSON - might be plain text SSE
                            # Try extracting after "data: "
                            plain_content = chunk_text[6:].strip()
                            if plain_content and not plain_content.startswith("{"):
                                full_response += plain_content
                
                # Save complete response after streaming finishes
                if full_response:
                    if is_guided_journey:
                        logger.info(f"[Guided Journey] Saving first assistant message ({len(full_response)} chars)")
                    asyncio.create_task(
                        self._save_assistant_response(chat_history, full_response, is_guided_journey)
                    )
                else:
                    logger.warning(f"[Chat History Middleware] No content accumulated from {chunk_count} chunks")
            
            except Exception as e:
                logger.error(f"[Chat History Middleware] Error in stream_with_history: {e}", exc_info=True)
                raise
        
        return StreamingResponse(
            stream_with_history(),
            media_type=response.media_type,
            headers=dict(response.headers) if hasattr(response, 'headers') else {}
        )
    
    async def _save_assistant_response(self, chat_history, message: str, is_guided_journey: bool = False):
        """Save assistant response (fire-and-forget)"""
        try:
            await chat_history.helper.save_assistant_message(message)
            if is_guided_journey:
                logger.info(f"[Guided Journey] Saved first assistant message ({len(message)} chars) for session {chat_history.session_id}")
            else:
                logger.info(f"[Chat History Middleware] Saved assistant response ({len(message)} chars)")
        except Exception as e:
            logger.error(f"[Chat History Middleware] Error saving assistant response: {e}")
