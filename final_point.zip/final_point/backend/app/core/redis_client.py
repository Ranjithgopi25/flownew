import redis
from redis import ConnectionPool
from redis.connection import Connection, SSLConnection
from typing import Optional, Any, Dict
import json
import logging

logger = logging.getLogger(__name__)

class RedisCache:
    _instance: Optional['RedisCache'] = None
    _client: Optional[redis.Redis] = None
    _pool: Optional[ConnectionPool] = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def initialize(self, config: dict) -> None:
        """Initialize Redis connection pool with config."""
        if not config.get("host"):
            logger.warning("[Redis] No host configured, Redis will not be available")
            self._client = None
            self._pool = None
            return
            
        try:
            # Get configuration
            host = config["host"]
            port = config.get("port", 6380)  
            password = config.get("password") or None
            use_ssl = config.get("ssl", True)  
            max_connections = 50
            
            # Choose connection class based on SSL setting
            connection_class = SSLConnection if use_ssl else Connection
            
            logger.info(f"[Redis] Configuring connection pool:")
            logger.info(f"  - Host: {host}")
            logger.info(f"  - Port: {port}")
            logger.info(f"  - SSL: {use_ssl}")
            logger.info(f"  - Max Connections: {max_connections}")
            
            # Create connection pool with optimal settings
            self._pool = ConnectionPool(
                connection_class=connection_class,
                host=host,
                port=port,
                password=password,
                socket_connect_timeout=5,
                socket_keepalive=True,
                max_connections=max_connections,
                retry_on_timeout=True,
                decode_responses=True
            )
            
            # Create Redis client from pool
            self._client = redis.Redis(connection_pool=self._pool)
            logger.info(f"[Redis] Connection pool created with max_connections={max_connections}")
            logger.info(f"[Redis] Client created with host={host}, port={port}")
            
            # Test connection
            try:
                ping_result = self._client.ping()
                if ping_result:
                    logger.info("[Redis] ✅ Connection test successful")
                else:
                    logger.error("[Redis] ❌ Connection test failed - ping returned False")
            except Exception as ping_error:
                logger.error(f"[Redis] ❌ Connection test failed with error: {ping_error}", exc_info=True)
                # Don't raise, let the app continue with fallback
                
        except Exception as e:
            logger.error(f"[Redis] ❌ Failed to initialize: {e}", exc_info=True)
            logger.warning("[Redis] ⚠️ Redis initialization failed - app will use fallback in-memory storage")
            # Set to None so is_available returns False
            self._client = None
            self._pool = None
    
    @property
    def is_available(self) -> bool:
        """Check if Redis is available."""
        if not self._client:
            logger.debug("[Redis] is_available: False (no client)")
            return False
        try:
            result = self._client.ping()
            logger.debug(f"[Redis] is_available: {result}")
            return result
        except Exception as e:
            logger.error(f"[Redis] is_available check failed: {e}", exc_info=True)
            return False
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        if not self.is_available:
            logger.debug(f"[Redis] Cannot get {key} - Redis not available")
            return None
        try:
            value = self._client.get(key)
            logger.debug(f"[Redis] Get {key}: {'found' if value else 'not found'}")
            return value
        except Exception as e:
            logger.error(f"[Redis] Error getting {key}: {e}", exc_info=True)
            return None
    
    def set(self, key: str, value: Any, ex: Optional[int] = None) -> bool:
        """Set value in cache."""
        logger.debug(f"[Redis] set() called for key={key}, ex={ex}")
        
        if not self.is_available:
            logger.warning(f"[Redis] Cannot set {key} - Redis not available")
            return False
        
        try:
            logger.debug(f"[Redis] Attempting to set {key} with value length={len(str(value))}")
            result = self._client.set(key, value, ex=ex)
            logger.info(f"[Redis] Set {key}: result={result}, type={type(result)}")
            return bool(result)
        except Exception as e:
            logger.error(f"[Redis] Error setting {key}: {e}", exc_info=True)
            return False
    
    def delete(self, key: str) -> bool:
        """Delete key from cache."""
        if not self.is_available:
            logger.debug(f"[Redis] Cannot delete {key} - Redis not available")
            return False
        try:
            result = self._client.delete(key)
            logger.debug(f"[Redis] Delete {key}: {result} keys deleted")
            return result > 0
        except Exception as e:
            logger.error(f"[Redis] Error deleting {key}: {e}", exc_info=True)
            return False
    
    def get_json(self, key: str) -> Optional[Dict]:
        """Get JSON value from cache."""
        if not self.is_available:
            logger.debug(f"[Redis] Cannot get_json {key} - Redis not available")
            return None
        try:
            value = self._client.get(key)
            if value:
                parsed = json.loads(value)
                logger.debug(f"[Redis] Get JSON {key}: found and parsed")
                return parsed
            logger.debug(f"[Redis] Get JSON {key}: not found")
            return None
        except json.JSONDecodeError as e:
            logger.error(f"[Redis] JSON decode error for {key}: {e}", exc_info=True)
            return None
        except Exception as e:
            logger.error(f"[Redis] Error getting JSON {key}: {e}", exc_info=True)
            return None
    
    def set_json(self, key: str, value: Dict, ex: Optional[int] = None) -> bool:
        """Set JSON value in cache."""
        logger.debug(f"[Redis] set_json() called for key={key}, ex={ex}")
        
        if not self.is_available:
            logger.warning(f"[Redis] Cannot set_json {key} - Redis not available (is_available={self.is_available})")
            return False
        
        try:
            logger.debug(f"[Redis] Serializing value to JSON for key={key}")
            json_str = json.dumps(value)
            logger.debug(f"[Redis] JSON string length for {key}: {len(json_str)} bytes")
            
            logger.debug(f"[Redis] Calling _client.set() for key={key}")
            result = self._client.set(key, json_str, ex=ex)
            
            logger.info(f"[Redis] Set JSON {key}: result={result}, type={type(result)}, bool={bool(result)}")
            
            if not result:
                logger.error(f"[Redis] set() returned falsy value: {result}")
            
            return bool(result)
        except (TypeError, json.JSONEncodeError) as e:
            logger.error(f"[Redis] JSON encode error for {key}: {e}", exc_info=True)
            return False
        except Exception as e:
            logger.error(f"[Redis] Error setting JSON {key}: {e}", exc_info=True)
            return False

# Singleton instance
cache = RedisCache()