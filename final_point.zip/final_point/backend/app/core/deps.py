from fastapi import Depends, HTTPException
from app.core.config import Settings, get_settings
from app.core.exceptions import LLMServiceException
from app.infrastructure.llm.llm_service import get_llm_service, LLMService
from app.common.factiva_client import FactivaClient
from langchain_openai import ChatOpenAI
from typing import Optional
from functools import lru_cache
from pydantic import BaseModel
import logging

logger = logging.getLogger(__name__)


def get_ddc_service(service_class):
    """
    Factory for DDC service dependency injection.
    """
    async def _get_service(
        llm_service: LLMService = Depends(get_llm_service)
    ):
        return service_class(llm_service)
    return _get_service


def get_tl_service(service_class):
    """
    Factory for TL service dependency injection.
    """
    async def _get_service(
        llm_service: LLMService = Depends(get_llm_service)
    ):
        return service_class(llm_service)
    return _get_service


def get_llm_client_agent(settings: Optional[Settings] = None) -> ChatOpenAI:
    """
    Return a ChatOpenAI client for Azure.
    Used by LangChain-based workflows (e.g., edit_content).
    """
    if settings is None:
        settings = get_settings()
    
    if not settings.AZURE_OPENAI_ENDPOINT or not settings.AZURE_OPENAI_API_KEY:
        logger.error("Azure OpenAI not configured - missing endpoint or API key")
        raise HTTPException(
            status_code=503,
            detail="LLM service unavailable: Azure OpenAI credentials not configured"
        )

    try:
        logger.info(f"Initializing Azure OpenAI Chat client with endpoint: {settings.AZURE_OPENAI_ENDPOINT}")
        chat_client = ChatOpenAI(
            api_key=settings.AZURE_OPENAI_API_KEY,
            model=settings.AZURE_OPENAI_DEPLOYMENT,
            openai_api_base=settings.AZURE_OPENAI_ENDPOINT,
            temperature=0,
            max_tokens=settings.LLM_MAX_TOKENS,
        )
        return chat_client
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to initialize Azure OpenAI Chat client: {str(e)}")
        raise HTTPException(
            status_code=503,
            detail=f"LLM service initialization failed: {str(e)}"
        )

def get_factiva_client(settings: Settings = Depends(get_settings)) -> Optional[FactivaClient]:
    """
    Factiva Client factory for dependency injection.
    Per-request instantiation with hardcoded credentials from config.
    """
    try:
        logger.debug(f"Initializing Factiva client with endpoint: {settings.FACTIVA_ENDPOINT}")
        return FactivaClient(
            api_key=settings.FACTIVA_API_KEY,
            endpoint=settings.FACTIVA_ENDPOINT,
            base_url=settings.FACTIVA_BASE_URL,
            username=settings.FACTIVA_SERVICE_ACCOUNT_USERNAME,
            client_id=settings.FACTIVA_SERVICE_ACCOUNT_CLIENT_ID,
            password=settings.FACTIVA_SERVICE_ACCOUNT_PASSWORD,
        )
    except Exception as e:
        logger.error(f"Failed to initialize Factiva client: {str(e)}")
        return None

# Chat History Service Dependencies

@lru_cache()
@lru_cache(maxsize=1)
def get_chat_history_repository():
    """
    Get chat history repository instance.
    Cached to reuse the same repository across requests.
    """
    from app.repositories.chat_history_repository import ChatHistoryRepository
    try:
        settings = get_settings()
        connection_string = settings.chat_db_connection_string
        logger.info("Initializing Chat History Repository with SQL Server connection")
        return ChatHistoryRepository(connection_string)
    except Exception as e:
        logger.error(f"Failed to initialize Chat History Repository: {str(e)}")
        raise HTTPException(
            status_code=503,
            detail=f"Chat History service unavailable: {str(e)}"
        )

def get_chat_history_service(
    repository = Depends(get_chat_history_repository)
):
    """
    Get chat history service instance with repository dependency.
    """
    from app.services.chat_history_service import ChatHistoryService
    try:
        return ChatHistoryService(repository)
    except Exception as e:
        logger.error(f"Failed to initialize Chat History Service: {str(e)}")
        raise HTTPException(
            status_code=503,
            detail=f"Chat History service initialization failed: {str(e)}"
        )


# Chat History Context for Optional Tracking

class ChatHistoryContext(BaseModel):
    """
    Context object holding chat history helper and metadata.
    Used to optionally enable chat history tracking in any endpoint.
    """
    helper: Optional[object] = None  # ChatHistoryHelper instance
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    source: str = "Chat"
    enabled: bool = False
    
    class Config:
        arbitrary_types_allowed = True


def create_chat_history_context(
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    source: Optional[str] = None
) -> ChatHistoryContext:
    """
    Factory function to create a ChatHistoryContext for optional chat history tracking.
    
    If user_id and session_id are provided, creates an enabled context with ChatHistoryHelper.
    Otherwise, returns a disabled context that won't save messages.
    
    This ensures backward compatibility - existing requests without these parameters
    continue to work unchanged, while new requests with parameters get chat history tracking.
    
    Args:
        user_id: User email or identifier (optional)
        session_id: Session UUID or identifier (optional)
        source: Module source (DDDC, Market_Intelligence, Cortex, Chat) (optional)
        
    Returns:
        ChatHistoryContext with helper if enabled, or disabled context
    """
    from app.common.chat_history_helper import ChatHistoryHelper
    
    context = ChatHistoryContext()
    
    # Only enable if both required parameters are provided
    if user_id and session_id:
        context.user_id = user_id
        context.session_id = session_id
        context.source = source or "Chat"
        
        try:
            context.helper = ChatHistoryHelper(
                user_id=user_id,
                session_id=session_id,
                source=context.source
            )
            context.enabled = context.helper._enabled
            
            if context.enabled:
                logger.info(f"[ChatHistory] Enabled for session={session_id}, source={context.source}")
            else:
                logger.debug(f"[ChatHistory] Disabled (helper not enabled)")
                
        except Exception as e:
            logger.warning(f"[ChatHistory] Failed to initialize helper: {e}")
            context.enabled = False
    else:
        logger.debug(f"[ChatHistory] Disabled (missing user_id or session_id)")
    
    return context
