from app.infrastructure.llm.base_services import BaseTLStreamingService
import logging
import json
from typing import Any
from app.features.thought_leadership.services.refine_content.graph import (
    run_refine_content_graph
)

logger = logging.getLogger(__name__)


class RefineContentService(BaseTLStreamingService):
    """
    Thin orchestration layer.
    ALL intelligence lives in LangGraph.
    This service ONLY normalizes request payload.
    """

    async def refine_content(self, request_data: dict[str, Any]):
        original_content = request_data.get("original_content", "").strip()
        services_list = request_data.get("services", [])

        if not original_content:
            yield (
                f"data: {json.dumps({'type': 'error', 'error': 'Original content is required'})}\n\n"
            )
            return

        services = self._parse_services(services_list)

        logger.info("[RefineContent] Executing Refine Content LangGraph")

        result = await run_refine_content_graph(
            original_content=original_content,
            services=services,
            llm_service=self.llm_service,
        )

        # ---------------------------
        # Stream refined content
        # ---------------------------
        if result.get("content") is not None:
            yield (
                f"data: {json.dumps({'type': 'content', 'content': result['content']})}\n\n"
            )

        # ---------------------------
        # Stream suggestions
        # ---------------------------
        if result.get("suggestions"):
            yield (
                f"data: {json.dumps({'type': 'suggestions', 'content': result['suggestions']})}\n\n"
            )

        # ---------------------------
        # Stream warnings
        # ---------------------------
        if result.get("warnings"):
            yield (
                f"data: {json.dumps({'type': 'warning', 'warnings': result['warnings']})}\n\n"
            )

    def _parse_services(self, services_list: list[dict[str, Any]]) -> dict[str, Any]:
        """
        Normalize API payload → LangGraph-friendly structure

        CONTRACT (IMPORTANT):
        - suggestions: bool
        - tone: str | None
        - expand/compress: share requested_word_limit
        - supporting_doc: expand-only
        """

        services: dict[str, Any] = {
            # Core controls
            "requested_word_limit": None,
            "is_expand": False,
            "tone": None,
            "research": False,
            "edit": False,
            "suggestions": False,

            # Research + documents
            "pwc_research_doc": None,
            "supporting_doc": None,
            "supporting_doc_instructions": None,

            # Research routing
            "research_topics": None,
            "proprietary": {},
            "externalResearch": {},
        }

        for s in services_list:
            if not s.get("isSelected"):
                continue

            t = (s.get("type") or "").lower()

            # ------------------------
            # EXPAND
            # ------------------------
            if t == "expand":
                services["requested_word_limit"] = s.get("expected_word_count")
                services["is_expand"] = True
                services["supporting_doc"] = s.get("supportingDoc")
                services["supporting_doc_instructions"] = s.get(
                    "expand_guidelines"
                )

            # ------------------------
            # COMPRESS
            # ------------------------
            elif t == "compress":
                services["requested_word_limit"] = s.get("expected_word_count")
                services["is_expand"] = False

            # ------------------------
            # TONE
            # ------------------------
            elif t == "adjust_audience_tone":
                services["tone"] = True
                services["audience_tone"] = s.get("audience_tone")

            # ------------------------
            # RESEARCH
            # ------------------------
            elif t == "enhanced_with_research":
                services["research"] = True
                services["research_topics"] = s.get("research_topics")
                services["proprietary"] = s.get("proprietary", {})
                services["thirdParty"] = s.get("thirdParty", {})
                services["externalResearch"] = s.get("externalResearch", {})

                pwc = s.get("pwc_content", {})
                if pwc.get("isSelected") and pwc.get("supportingDoc"):
                    services["pwc_research_doc"] = pwc["supportingDoc"]

            # ------------------------
            # EDIT
            # ------------------------
            elif t == "edit_content":
                services["edit"] = True
                services["editors"] = s.get("editors")

            # ------------------------
            # SUGGESTIONS (BOOLEAN ONLY)
            # ------------------------
            elif t == "improvement_suggestions":
                services["suggestions"] = True
        print("input ==================================", services)
        return services

    async def execute(self, *args, **kwargs):
        return await self.refine_content(*args, **kwargs)
