from typing import Optional, Dict, Any, List
import logging
import re
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from app.features.chat.services.data_source_agent import create_data_source_agent
from app.features.thought_leadership.services.prep_client_meeting_service import PrepClientMeetingService
from fastapi import Depends, HTTPException, APIRouter
from app.features.thought_leadership.utils.audience_tone_defaults import apply_audience_tone_defaults
from app.core.deps import get_tl_service, get_settings
from app.core.config import Settings, config
logger = logging.getLogger(__name__)

class PrepClientMeetingRequest(BaseModel):
    messages: List[Dict[str, Any]]
    stream: bool = True
    content_type: Optional[str] = None
    topic: Optional[str] = None
    word_limit: Optional[int] = None
    audience_tone: Optional[str] = None
    clientname: Optional[str] = None
    outline_doc: Optional[str] = None
    supporting_doc: Optional[str] = None
    use_research: Optional[bool] = False
    services: Optional[Dict[str, Any]] = None
    
class MeetingResearchService:
    """Service for conducting multi-source research and generating client meeting briefs"""
    
    def __init__(
        self,
        prep_service,
        azure_endpoint: str,
        api_key: str,
        api_version: str,
        deployment_name: str
    ):
        self.prep_service = prep_service
        self.azure_endpoint = azure_endpoint
        self.api_key = api_key
        self.api_version = api_version
        self.deployment_name = deployment_name
    
    @staticmethod
    def extract_research_info(content: str) -> dict:
        """Extract research-related information from content."""
        research_requested = re.search(r'Research Requested:\s*(.+?)(?:\n|$)', content)
        research_topics = re.search(r'Research Topics:\s*(.+?)(?:\n|$)', content)
        research_sources = re.search(r'Research Sources:\s*(.+?)(?:\n|$)', content)
        additional_guidelines = re.search(r'Additional Guidelines:\s*(.+?)(?:\n|$)', content)
        return {
            'requested': research_requested.group(1).strip().lower() == 'yes' if research_requested else False,
            'topics': research_topics.group(1).strip() if research_topics else None,
            'sources': research_sources.group(1).strip() if research_sources else None,
            'additional_guidelines': additional_guidelines.group(1).strip() if additional_guidelines else None
        }
    
    @staticmethod
    def parse_client_and_topic(user_prompt: str, clientname: str = None, topic: str = None) -> tuple:
        """Parse client name and topic from user prompt if not provided"""
        if not topic or not clientname:
            for line in user_prompt.splitlines():
                ln = line.strip()
                if not topic and ln.lower().startswith("topic:"):
                    topic = ln.split(":", 1)[1].strip()
                if not clientname and (ln.lower().startswith("client:") or 
                                      ln.lower().startswith("client name:") or 
                                      ln.lower().startswith("clientname:")):
                    clientname = ln.split(":", 1)[1].strip()
        return clientname, topic
    
    async def conduct_research(
        self,
        user_prompt: str,
        clientname: str,
        topic: str,
        audience_tone: str,
        research_info: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Conduct multi-source research using LangGraph agent
        
        Returns:
            Research context string to be appended to supporting_doc
        """
        try:
            logger.info(f"[MeetingResearch] Initializing LangGraph Agent for multi-source query")
            
            langgraph_agent = create_data_source_agent(
                azure_endpoint=self.azure_endpoint,
                api_key=self.api_key,
                api_version=self.api_version,
                deployment_name=self.deployment_name
            )
            
            clientname, topic = self.parse_client_and_topic(user_prompt, clientname, topic)
            
            if research_info is None:
                research_info = self.extract_research_info(user_prompt)
            
            search_topics = research_info.get('topics') or topic
            search_query = f"meeting with {clientname} for topic {search_topics}".strip()
            
            if not search_query:
                logger.warning("[MeetingResearch] Search query is empty — provide 'clientname' and 'topic'")
                return ""
            
            additional_guidelines = research_info.get('additional_guidelines') or ''
            
            agent_messages = [
                                    {
                                        "role": "user",
                                        "content": f"""
                                You are a PwC MI&I research agent preparing intelligence for a CLIENT MEETING BRIEFING.

                                **MEETING CONTEXT:**
                                - Client: {clientname}
                                - Topic: {topic}
                                - Audience: {audience_tone}

                                **YOUR MISSION:**
                                Gather comprehensive, structured intelligence to support a partner-ready client meeting brief.
                                The final output will follow a strict template requiring specific data points across multiple sections.

                                ========================
                                REQUIRED RESEARCH AREAS
                                ========================

                                You MUST retrieve data for ALL applicable sections below. Use ALL relevant tools exhaustively.

                                **1. CLIENT SNAPSHOT (MANDATORY)**
                                Required data points:
                                - Total revenue for {clientname}
                                - Total revenue for parent company (if different)
                                - Primary business lines
                                - Key products/services and brands
                                - Key competitors and their primary brands
                                - Market share of client and competitors
                                - Competitive differentiation vs peers
                                - Geographic footprint (core and growth markets)
                                - Physical footprint (stores, plants, R&D, data centers, major offices)
                                - Customer base profile

                                Tools to use: CapitalIQ, Tavily, Factiva

                                **2. FINANCIAL OVERVIEW (MANDATORY)**
                                (Primary source: CapIQ; fallback to SEC EDGAR or reputable financial news or )
                                Required metrics - retrieve separately:
                                - YoY revenue growth
                                - Gross profit margin
                                - YoY stock performance
                                - Efficiency ratio (or industry-relevant equivalent)
                                - 3-year total shareholder returns (TSR)

                                Tools to use: CapitalIQ (PRIMARY), fallback to web sources if unavailable

                                **3. LEADERSHIP & GOVERNANCE (MANDATORY)**
                                Required data:
                                - Key leadership names and roles (C-suite)
                                - Board composition overview
                                - Recent leadership or board changes (last 12 months)
                                - Auditors and advisors

                                Tools to use: BoardEx (PRIMARY), fallback to web sources if unavailable

                                **4. INDUSTRY & MARKET CONTEXT**
                                Related to topic: {topic}
                                Required:
                                - Industry value chain overview
                                - Key topic-specific considerations for this industry
                                - Recent industry trends related to {topic} (last 12 months)
                                - Common industry challenges related to {topic}
                                - Potential opportunities related to {topic}
                                - Key cost drivers relevant to {topic}

                                Tools to use: Connected Source (retrieve_knowledge_passages), Tavily, Factiva

                                **5. COMPETITIVE INSIGHTS**
                                Required:
                                - Major competitor news and announcements (last 3-6 months)
                                - Competitor developments specifically related to {topic} (last 12 months)
                                - Notable competitor investments, partnerships, or acquisitions related to {topic}

                                Tools to use: Factiva (PRIMARY), Tavily

                                **6. RECENT DEVELOPMENTS & NEWS**
                                Client-specific only for {clientname}:
                                - Key client developments (last 3-6 months)
                                - Client news specifically related to {topic} (last 12 months)
                                - Client news related to {audience_tone} audience (last 12 months)

                                Tools to use: Factiva (PRIMARY), Tavily

                                **7. EXTERNAL COMMENTARY**
                                Required:
                                - Analyst commentary on {clientname} (last 6 months)
                                - Industry expert views on {topic} in this sector (last 6 months)
                                - Clearly attribute sentiment (cautious/neutral/bullish) and source

                                Tools to use: Factiva, Tavily

                                **8. PWC THOUGHT LEADERSHIP**
                                Required (with direct links):
                                - PwC publications on {topic} + {clientname}'s industry
                                - PwC publications on {topic} across industries
                                - Strategy& perspectives if relevant

                                Tools to use: Connected Source (retrieve_knowledge_passages)

                                ========================
                                EXECUTION REQUIREMENTS
                                ========================

                                1. **You can call any tool anytime when needed**
                                - USE ALL tools as required to gather complete data
                                - Always get data from https://www.sec.gov/search-filings for financials and filings
                                - Finally Tavily for gaps or validation

                                2. **For each data point:**
                                - Cite the source clearly
                                - Include dates for time-sensitive information
                                - Flag if data is unavailable rather than skip it

                                3. **Do NOT:**
                                - Infer or estimate financial data
                                - Fabricate leadership names or titles
                                - Merge or skip required sections
                                - Stop after first tool call
                                - Don't tell which tool failed to fetch data or successfully fechted the data

                                4. **Output format:**
                                Structure your findings clearly under each research area heading.
                                Use bullets for clarity.
                                Include source attribution for every claim.

                                ========================
                                QUALITY STANDARD
                                ========================

                                The partner needs decision-ready intelligence, not a tutorial.
                                - Prioritize recent, material information
                                - Focus on facts that illuminate: decisions, tensions, competitive position, and PwC relevance
                                - Be comprehensive but surgical - every data point should serve the meeting objective

                                Search Query Focus: {search_query}

                                {additional_guidelines}

                                **BEGIN RESEARCH NOW. Use ALL applicable tools exhaustively.**
                                """
                                    }
                                ]
            
            logger.info(f"[MeetingResearch] Calling LangGraph Agent with query: {search_query}")
            
            agent_response = await langgraph_agent.process_query(agent_messages)
            
            if agent_response:
                langgraph_context = f"""
--- Multi-Source Research Intelligence Report ---

The following research was compiled by an AI Agent that automatically queried multiple data sources. 

Agent Research Output:
{agent_response}

--- End of Research Intelligence ---
"""
                logger.info("[MeetingResearch] LangGraph Agent context generated successfully")
                langgraph_agent.close()
                return langgraph_context
            else:
                logger.warning("[MeetingResearch] LangGraph Agent returned empty response")
                langgraph_agent.close()
                return ""
                
        except Exception as e:
            logger.error(f"[MeetingResearch] LangGraph Agent error: {e}", exc_info=True)
            return ""
    
    async def generate_meeting_brief(
        self,
        user_prompt: str,
        clientname: str,
        topic: str,
        audience_tone: str,
        word_limit: int,
        outline_doc: str = "",
        supporting_doc: str = ""
    ) -> StreamingResponse:
        """
        Generate complete meeting brief with research and streaming response
        
        Returns:
            StreamingResponse with the generated meeting brief
        """
        logger.info(f"[MeetingBrief] Starting brief generation for client: {clientname}, topic: {topic}")
        
        # Conduct research
        research_info = self.extract_research_info(user_prompt)
        langgraph_context = await self.conduct_research(
            user_prompt=user_prompt,
            clientname=clientname,
            topic=topic,
            audience_tone=audience_tone,
            research_info=research_info
        )
        
        # Add research to supporting doc
        if langgraph_context:
            supporting_doc += langgraph_context
        
        logger.info(f"[MeetingBrief] Final supporting doc length: {len(supporting_doc)}")
        
        # Generate streaming response
        return StreamingResponse(
            self.prep_service.draft_client_meeting_prompt(
                user_prompt=user_prompt,
                clientname=clientname,
                topic=topic,
                audience_tone=audience_tone,
                word_limit=word_limit,
                outline_doc=outline_doc,
                supporting_doc=supporting_doc,
                agent_research_context=langgraph_context
            ),
            media_type="text/event-stream"
        )

router = APIRouter()
# Updated router using the class
@router.post("")
async def prep_client_meeting_workflow(
    request: PrepClientMeetingRequest,
    service: PrepClientMeetingService = Depends(get_tl_service(PrepClientMeetingService)),
    settings: Settings = Depends(get_settings)
):
    try:
        user_prompt = request.messages[-1].get("content", "") if request.messages else ""
        
        logger.info(f"[meeting] User prompt length: {len(user_prompt)}")
        
        # Extract clientname
        clientname = (request.clientname or "").strip()
        services = request.model_dump().get("services")
        if not clientname and services and isinstance(services, dict):
            draft = services.get("draft", {})
            if isinstance(draft, dict):
                clientname = (draft.get("client") or "").strip()
        
        # Extract topic
        draft = request.services.get("draft", {}) if request.services else {}
        topic = (draft.get("topic") or "").strip() if isinstance(draft, dict) else ""
        
        content_type = "Client Meeting Preparation"
        audience_tone = apply_audience_tone_defaults(content_type, request.audience_tone)
        word_limit_int = request.word_limit or settings.TL_WORD_LIMIT_DEFAULT
        outline_doc = request.outline_doc or ""
        supporting_doc = request.supporting_doc or ""
        
        logger.info(
            f"[PARSE] resolved_clientname='{clientname}', "
            f"source={'services.draft.client' if request.services else 'request.clientname'}, "
            f"topic='{topic}', Audience='{audience_tone}'"
        )
        
        # Initialize research service
        research_service = MeetingResearchService(
            prep_service=service,
            azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
            api_key=config.AZURE_OPENAI_API_KEY,
            api_version=config.AZURE_OPENAI_API_VERSION,
            deployment_name=config.AZURE_OPENAI_DEPLOYMENT
        )
        
        # Generate meeting brief with research
        return await research_service.generate_meeting_brief(
            user_prompt=user_prompt,
            clientname=clientname,
            topic=topic,
            audience_tone=audience_tone,
            word_limit=word_limit_int,
            outline_doc=outline_doc,
            supporting_doc=supporting_doc
        )
        
    except Exception as e:
        logger.error(f"[meeting] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))