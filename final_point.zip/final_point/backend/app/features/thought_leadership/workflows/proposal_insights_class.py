from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from app.features.thought_leadership.services.proposal_insights_service import ProposalInsightsService
from app.features.thought_leadership.utils.audience_tone_defaults import apply_audience_tone_defaults
from app.features.chat.services.data_source_agent import create_data_source_agent
from app.core.deps import get_tl_service, get_settings
from app.core.config import Settings, config
import logging
import re
import json

logger = logging.getLogger(__name__)

class ProposalInsightsRequest(BaseModel):
    messages: List[Dict[str, Any]]
    stream: bool = True
    content_type: Optional[str] = None
    topic: Optional[str] = None
    word_limit: Optional[int] = None
    audience_tone: Optional[str] = None
    clientname: Optional[str] = None
    outline_doc: Optional[str] = None
    supporting_doc: Optional[str] = None
    use_research: Optional[bool] = False
    services: Optional[Dict[str, Any]] = None

class ProposalResearchService:
    """Service for conducting multi-source research and generating proposal insights"""
    
    def __init__(
        self,
        proposal_service,
        azure_endpoint: str,
        api_key: str,
        api_version: str,
        deployment_name: str
    ):
        self.proposal_service = proposal_service
        self.azure_endpoint = azure_endpoint
        self.api_key = api_key
        self.api_version = api_version
        self.deployment_name = deployment_name
    
    @staticmethod
    def extract_research_info(content: str) -> dict:
        """Extract research-related information from content."""
        research_requested = re.search(r'Research Requested:\s*(.+?)(?:\n|$)', content)
        research_topics = re.search(r'Research Topics:\s*(.+?)(?:\n|$)', content)
        research_sources = re.search(r'Research Sources:\s*(.+?)(?:\n|$)', content)
        additional_guidelines = re.search(r'Additional Guidelines:\s*(.+?)(?:\n|$)', content)
        return {
            'requested': research_requested.group(1).strip().lower() == 'yes' if research_requested else False,
            'topics': research_topics.group(1).strip() if research_topics else None,
            'sources': research_sources.group(1).strip() if research_sources else None,
            'additional_guidelines': additional_guidelines.group(1).strip() if additional_guidelines else None
        }
    
    @staticmethod
    def parse_client_and_topic(user_prompt: str, clientname: str = None, topic: str = None) -> tuple:
        """Parse client name and topic from user prompt if not provided"""
        if not topic or not clientname:
            for line in user_prompt.splitlines():
                ln = line.strip()
                if not topic and ln.lower().startswith("topic:"):
                    topic = ln.split(":", 1)[1].strip()
                if not clientname and (ln.lower().startswith("client:") or 
                                      ln.lower().startswith("client name:") or 
                                      ln.lower().startswith("clientname:")):
                    clientname = ln.split(":", 1)[1].strip()
        return clientname, topic
    
    async def conduct_research(
        self,
        user_prompt: str,
        clientname: str,
        topic: str,
        research_info: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Conduct multi-source research using LangGraph agent
        
        Returns:
            Research context string to be appended to supporting_doc
        """
        try:
            logger.info(f"[ProposalResearch] Initializing LangGraph Agent for multi-source query")
            
            langgraph_agent = create_data_source_agent(
                azure_endpoint=self.azure_endpoint,
                api_key=self.api_key,
                api_version=self.api_version,
                deployment_name=self.deployment_name
            )
            
            clientname, topic = self.parse_client_and_topic(user_prompt, clientname, topic)
            
            if research_info is None:
                research_info = self.extract_research_info(user_prompt)
            
            search_topics = research_info.get('topics') or topic
            search_query = f"{clientname} {search_topics}".strip()
            
            if not search_query:
                logger.warning("[ProposalResearch] Search query is empty — provide 'clientname' and 'topic'")
                return ""
            
            additional_guidelines = research_info.get('additional_guidelines') or ''
            
            # Placeholder for agent messages - you will add your prompt here
            agent_messages = [
                            {
                                "role": "user",
                                "content": f"""
                        You are a PwC MI&I research agent preparing comprehensive intelligence for a PROPOSAL INPUT PACK.

                        **PROPOSAL CONTEXT:**
                        - Client: {clientname}
                        - Proposal Topic: {topic}

                        **YOUR MISSION:**
                        Gather exhaustive, structured intelligence to support a decision-ready proposal input pack.
                        This is NOT a final proposal - it's an input pack that allows senior associates/managers to:
                        1. Compare multiple credible delivery options
                        2. Draft a PwC-quality proposal efficiently
                        3. Access relevant precedents and methodologies

                        The final output will follow a strict template with 7 core sections (A-G).

                        ========================
                        REQUIRED RESEARCH AREAS
                        ========================

                        You MUST retrieve data for ALL sections below. Use ALL relevant tools exhaustively.
                        Focus on DECISION-READY inputs, not polished prose.

                        **A. COMMON CLIENT CONTEXT (MANDATORY)**
                        Required intelligence on {clientname}:
                        - Company background (industry position, scale, business model, geography)
                        - Current-state challenges and pain points related to {topic}
                        - Strategic drivers (why does this matter NOW to the client)
                        - Success criteria in client's language (what does "winning" look like)
                        - Known constraints (budget, timeline, privacy, compliance, CX standards)
                        - Non-negotiables (must-haves vs. nice-to-haves)
                        - Recent strategic announcements or initiatives related to {topic}

                        Tools to use: CapitalIQ (company profile), Factiva (recent developments), Connected Source (industry context), Tavily

                        **B. PROPOSAL STRUCTURE & PATTERN GUIDANCE (MANDATORY)**
                        Required:
                        - Research standard proposal structures for {topic} 
                        - Identify which proposal sections are most critical for this client/topic
                        - Note any industry-specific requirements (e.g., healthcare compliance sections, financial services risk sections)

                        Tools to use: Connected Source (PwC proposal patterns), Tavily (industry best practices)

                        **C. RELEVANT PWC PRECEDENT & REFERENCE MATERIALS (MANDATORY)**
                        This is CRITICAL - you must exhaustively search for:

                        **C1. Sample Reference Proposals:**
                        Find 3-5 similar PwC proposals:
                        - Search criteria: {topic} proposal/engagement
                        - For each proposal found:
                        * Proposal title + link
                        * LOS (line of service), industry, topic
                        * Why structurally/conceptually useful (similar scope, client type, delivery model)
                        - DO NOT summarize proposals - focus on why they're useful patterns

                        **C2. Similar Approaches / Background Materials:**
                        Find 3-5 relevant materials:
                        - Methodologies, whitepapers, approach documents
                        - Search criteria: {topic} + methodology OR framework OR approach
                        - For each:
                        * Title + link
                        * What this helps reader understand (delivery model, analytics approach, operating model)

                        **C3. Standard PwC Methodologies & Frameworks:**
                        Find 2-4 relevant frameworks:
                        - PwC proprietary methodologies for {topic}
                        - Accelerators or tools that could apply
                        - For each:
                        * Name + link
                        * One-line relevance note

                        Tools to use: Connected Source (PRIMARY - exhaustive search), Tavily (validation)

                        **D. PROPOSAL OPTIONS INTELLIGENCE (MANDATORY)**
                        Research multiple delivery approaches for {topic}:

                        Required for benchmarking 3-4 delivery options:
                        - Industry standard approaches to {topic}
                        - How competitors (Big 4, boutiques) typically structure similar engagements
                        - Different scope levels (e.g., advisory-only vs. implementation, pilot vs. full rollout)
                        - Alternative delivery models (agile/iterative vs. waterfall, staff aug vs. fixed deliverable)
                        - Typical engagement durations for each approach
                        - Cost profiles ($ / $$ / $$$ relative positioning)

                        For each potential option, gather:
                        - Core objective and primary differentiator
                        - Best-fit client scenarios
                        - Typical scope boundaries
                        - Risk profiles
                        - Resource intensity

                        Tools to use: Connected Source (PwC approaches), Factiva (competitor approaches), Tavily

                        **E. OPTION-LEVEL DETAIL INTELLIGENCE (MANDATORY)**
                        For each delivery option identified in Section D, research:

                        **E1. Scope & Requirements Benchmarks:**
                        - Typical in-scope vs. out-of-scope activities for {topic} engagements
                        - Client effort/responsibility expectations by delivery model
                        - Common assumptions in proposals for {topic}

                        **E2. Solution & Delivery Approaches:**
                        - Delivery phase patterns (discovery, design, build, deploy, sustain)
                        - Key activities by phase
                        - Standard PwC methodologies/tools for each phase
                        - Change management approaches for {topic} 

                        **E3. Deliverables & Outcomes:**
                        - Standard deliverables for {topic} engagements
                        - Expected business outcomes (KPIs, metrics)
                        - Value realization timelines
                        - Case study evidence of outcomes (if available)

                        **E4. Timeline, Team & Governance:**
                        - Typical engagement durations by scope level
                        - Team composition patterns (seniority mix, roles)
                        - Client governance models for {topic}
                        - Decision point frameworks

                        **E5. Commercials & Risk Profile:**
                        - Pricing model patterns (T&M, fixed fee, value-based, hybrid)
                        - Typical effort ranges (person-weeks/months)
                        - Common risks and mitigations for {topic}
                        - Factors that increase/decrease risk

                        Tools to use: Connected Source (PRIMARY for PwC standards), Factiva (market benchmarks), Tavily

                        **F. COMPETITIVE INTELLIGENCE (MANDATORY)**
                        Required:
                        - How are competitors positioning similar offerings for {topic}
                        - Competitor case studies or announcements in {topic} (last 12 months)
                        - Emerging alternative providers (tech platforms, boutiques)
                        - What differentiates PwC's approach from competitors

                        Tools to use: Factiva (PRIMARY), Connected Source, Tavily

                        **G. RELEVANT PWC CREDENTIALS (MANDATORY)**
                        Find 4-6 strong credentials:
                        - PwC case studies for {topic}
                        - PwC case studies for {topic} in adjacent industries
                        - PwC credentials with {clientname} (if any)
                        - For each credential:
                        * Title + link
                        * One-line relevance note (why it matters for this proposal)
                        - Prioritize credentials with quantified outcomes

                        Tools to use: Connected Source (PRIMARY - exhaustive search)

                        ========================
                        EXECUTION REQUIREMENTS
                        ========================

                        1. **Prioritize PwC precedent research:**
                        - Connected Source is your PRIMARY tool for sections C and G
                        - Search exhaustively - don't stop after first result
                        - Search variations: "{topic}", "{topic} methodology", "{topic} framework", "{topic} approach", "{topic} proposal", "{topic} case study"

                        2. **Call tools strategically:**
                        - Connected Source FIRST for all PwC materials (proposals, methodologies, credentials)
                        - CapitalIQ for client company profile
                        - Factiva for client news, competitor approaches
                        - Tavily for industry benchmarks, validation

                        3. **For each PwC material found:**
                        - Always include title AND link
                        - Add one-line relevance note
                        - Do NOT summarize full documents - just explain why useful

                        4. **For delivery options:**
                        - Research at least 3-4 distinct approaches
                        - Make trade-offs explicit (benefits vs. what client gives up)
                        - Use relative cost indicators ($ / $$ / $$$)

                        5. **If a tool returns no data:**
                        - Explicitly state: "Checked Connected Source for [{topic} proposals] - no results"
                        - Try search variations before flagging as unavailable
                        - For PwC materials, try broader then narrower search terms

                        6. **Do NOT:**
                        - Create fictional PwC proposals or credentials
                        - Summarize full proposal documents
                        - Skip precedent research due to initial null results
                        - Present generic delivery options without PwC-specific grounding

                        7. **Output structure:**
                        Organize findings under clear section headings (A through G).
                        Use "At-a-glance" summaries where specified.
                        Prioritize comparison-ready format (side-by-side evaluation).
                        Include source citations and links inline.

                        ========================
                        QUALITY STANDARD
                        ========================

                        Senior associates/managers reading this should be able to:
                        - Quickly understand 3-4 credible delivery options
                        - Access 8-12 relevant PwC precedents (proposals, methodologies, credentials)
                        - Draft proposal sections without starting from scratch
                        - Make informed recommendations on approach and pricing

                        This is an INPUT PACK, not final prose:
                        - Emphasize STRUCTURE over polish
                        - Emphasize LINKS over summaries
                        - Emphasize COMPARISON over comprehensive narrative
                        - Make trade-offs explicit (what's different between options)

                        Research Query Focus: {search_query}

                        {additional_guidelines}

                        **BEGIN COMPREHENSIVE RESEARCH NOW. Prioritize Connected Source for PwC materials (sections C and G). Use ALL tools across all sections.**
                        """
                            }
                        ]
            
            logger.info(f"[ProposalResearch] Calling LangGraph Agent with query: {search_query}")
            
            agent_response = await langgraph_agent.process_query(agent_messages)
            
            if agent_response:
                langgraph_context = f"""
--- Multi-Source Research Intelligence Report ---

The following research was compiled by an AI Agent that automatically queried multiple data sources. 

Agent Research Output:
{agent_response}

--- End of Research Intelligence ---
"""
                logger.info("[ProposalResearch] LangGraph Agent context generated successfully")
                langgraph_agent.close()
                return langgraph_context
            else:
                logger.warning("[ProposalResearch] LangGraph Agent returned empty response")
                langgraph_agent.close()
                return ""
                
        except Exception as e:
            logger.error(f"[ProposalResearch] LangGraph Agent error: {e}", exc_info=True)
            return ""
    
    async def generate_proposal_insights(
        self,
        user_prompt: str,
        clientname: str,
        topic: str,
        audience_tone: str,
        word_limit: int,
        outline_doc: str = "",
        supporting_doc: str = ""
    ) -> StreamingResponse:
        """
        Generate complete proposal insights with research and streaming response
        
        Returns:
            StreamingResponse with the generated proposal insights
        """
        logger.info(f"[ProposalInsights] Starting insights generation for client: {clientname}, topic: {topic}")
        
        # Conduct research
        research_info = self.extract_research_info(user_prompt)
        langgraph_context = await self.conduct_research(
            user_prompt=user_prompt,
            clientname=clientname,
            topic=topic,
            research_info=research_info
        )
        
        # Add research to supporting doc
        if langgraph_context:
            supporting_doc += langgraph_context
        
        logger.info(f"[ProposalInsights] Final supporting doc length: {len(supporting_doc)}")
        
        # Generate streaming response
        return StreamingResponse(
            self.proposal_service.proposal_insights_prompt(
                user_prompt=user_prompt,
                clientname=clientname,
                topic=topic,
                audience_tone=audience_tone,
                word_limit=word_limit,
                outline_doc=outline_doc,
                supporting_doc=supporting_doc,
                agent_research_context=langgraph_context
            ),
            media_type="text/event-stream"
        )

router = APIRouter()
# Updated router using the class
@router.post("")
async def proposal_insights_workflow(
    request: ProposalInsightsRequest,
    service: ProposalInsightsService = Depends(get_tl_service(ProposalInsightsService)),
    settings: Settings = Depends(get_settings)
):
    try:
        user_prompt = request.messages[-1].get("content", "") if request.messages else ""
        
        logger.info(f"[Proposal Insights] User prompt length: {len(user_prompt)}")
        
        # Extract topic and clientname
        topic = request.topic or ""
        clientname = (request.clientname or "").strip()
        services = request.model_dump().get("services")
        
        if not clientname and services and isinstance(services, dict):
            draft = services.get("draft", {})
            if isinstance(draft, dict):
                clientname = (draft.get("client") or "").strip()
        
        if not topic and services and isinstance(services, dict):
            draft = services.get("draft", {})
            if isinstance(draft, dict):
                topic = (draft.get("topic") or "").strip()
        
        content_type = "Gather Proposal Insights"
        audience_tone = apply_audience_tone_defaults(content_type, request.audience_tone)
        word_limit_int = request.word_limit or settings.TL_WORD_LIMIT_DEFAULT
        supporting_doc = request.supporting_doc or ''
        outline_doc = request.outline_doc or ''
        
        logger.info(
            f"[PARSE] Parsed values - Topic: '{topic}', Client Name: '{clientname}', "
            f"Word Limit: '{word_limit_int}', Audience: '{audience_tone}'"
        )
        
        # Initialize research service
        research_service = ProposalResearchService(
            proposal_service=service,
            azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
            api_key=config.AZURE_OPENAI_API_KEY,
            api_version=config.AZURE_OPENAI_API_VERSION,
            deployment_name=config.AZURE_OPENAI_DEPLOYMENT
        )
        
        # Generate proposal insights with research
        return await research_service.generate_proposal_insights(
            user_prompt=user_prompt,
            clientname=clientname,
            topic=topic,
            audience_tone=audience_tone,
            word_limit=word_limit_int,
            outline_doc=outline_doc,
            supporting_doc=supporting_doc
        )
        
    except Exception as e:
        logger.error(f"[Proposal Insights] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))