from typing import Optional, Dict, Any, List
import logging
import re
import json
from pydantic import BaseModel
from fastapi.responses import StreamingResponse
from app.features.chat.services.data_source_agent import create_data_source_agent
from app.features.thought_leadership.services.pov_service import POVService
from fastapi import Depends, HTTPException, APIRouter
from app.features.thought_leadership.utils.audience_tone_defaults import apply_audience_tone_defaults
from app.core.deps import get_tl_service, get_factiva_client, get_settings
from app.common.factiva_client import FactivaClient
from app.core.config import Settings, config
from app.utils.market_intelligence_agent.graph import get_market_insights

logger = logging.getLogger(__name__)

class POVRequest(BaseModel):
    messages: List[Dict[str, Any]]
    stream: bool = True
    improvement_prompt: Optional[str] = None
    content_type: Optional[str] = None
    topic: Optional[str] = None
    word_limit: Optional[str] = None
    audience_tone: Optional[str] = None
    outline_doc: Optional[str] = None
    supporting_doc: Optional[str] = None
    use_factiva_research: Optional[bool] = None
    services: Optional[Dict[str, Any]] = None
    use_research: Optional[bool] = False

class POVResearchService:
    """Service for conducting multi-source research and generating POV content"""
    
    def __init__(
        self,
        pov_service,
        azure_endpoint: str,
        api_key: str,
        api_version: str,
        deployment_name: str
    ):
        self.pov_service = pov_service
        self.azure_endpoint = azure_endpoint
        self.api_key = api_key
        self.api_version = api_version
        self.deployment_name = deployment_name
    
    @staticmethod
    def extract_research_info(content: str) -> dict:
        """Extract research-related information from content."""
        research_requested = re.search(r'Research Requested:\s*(.+?)(?:\n|$)', content)
        research_topics = re.search(r'Research Topics:\s*(.+?)(?:\n|$)', content)
        research_sources = re.search(r'Research Sources:\s*(.+?)(?:\n|$)', content)
        additional_guidelines = re.search(r'Additional Guidelines:\s*(.+?)(?:\n|$)', content)
        
        return {
            'requested': research_requested.group(1).strip().lower() == 'yes' if research_requested else False,
            'topics': research_topics.group(1).strip() if research_topics else None,
            'sources': research_sources.group(1).strip() if research_sources else None,
            'additional_guidelines': additional_guidelines.group(1).strip() if additional_guidelines else None
        }
    
    @staticmethod
    def is_improvement_request(improvement_prompt: Optional[str]) -> bool:
        """Check if this is an improvement request"""
        return improvement_prompt is not None and improvement_prompt.strip()
    
    @staticmethod
    def build_improvement_prompt(original_prompt: str, improvement_feedback: str, original_content: str) -> str:
        """Build enhanced prompt with improvement feedback"""
        improvement_message = f"""This is an improvement iteration. The user has provided specific improvement instructions along with previously generated content. Please apply ONLY the requested improvements while regenerating the entire content.

User Improvement Request:
{improvement_feedback}

Original Generated Content:
{original_content}

Please regenerate the content with the following approach:
1. Read the user's improvement request carefully
2. Preserve the overall structure and length expectations
3. Apply the requested improvements throughout
4. Maintain consistency with the original topic and audience
5. Ensure the improved content flows naturally

{original_prompt}"""
        return improvement_message
    
    def parse_user_prompt(self, user_prompt: str, request: POVRequest) -> Dict[str, Any]:
        """Parse user prompt and extract parameters"""
        params = {
            'content_type': '',
            'topic': '',
            'word_limit': '',
            'audience_tone': '',
            'supporting_doc': '',
            'outline_doc': '',
            'original_generated_content': ""
        }
        
        # Check if using structured services.draft object
        if request.services and request.services.get('draft'):
            draft_data = request.services.get('draft', {})
            logger.info(f"[POV] Found structured services.draft object - extracting data")
            
            # Extract content type mapping
            content_type_key = draft_data.get('content_type', '')
            if content_type_key == 'article':
                params['content_type'] = 'Article'
            elif content_type_key == 'blog':
                params['content_type'] = 'Blog'
            elif content_type_key == 'executive_brief':
                params['content_type'] = 'Executive Brief'
            elif content_type_key == 'white_paper':
                params['content_type'] = 'White Paper'
            
            params['topic'] = draft_data.get('topic', '')
            params['word_limit'] = draft_data.get('word_limit', '')
            params['audience_tone'] = draft_data.get('audience_tone', '')
            
            # Extract outline data
            outline_info = draft_data.get('outline', {})
            if outline_info:
                params['outline_doc'] = outline_info.get('content', '')
            
            # Extract supporting documents
            supporting_docs_info = draft_data.get('supporting_documents', {})
            if supporting_docs_info:
                params['supporting_doc'] = supporting_docs_info.get('content', '')
            
            logger.info(f"[POV] Extracted from services.draft - content_type='{params['content_type']}', topic='{params['topic']}', word_limit='{params['word_limit']}', audience_tone='{params['audience_tone']}'")
        else:
            # Fall back to parsing from user_prompt
            logger.info(f"[POV] No services.draft found, parsing from user_prompt")
            
            lines = user_prompt.splitlines()
            i = 0
            while i < len(lines):
                line = lines[i]
                logger.debug(f"[PARSE] Processing line {i}: {repr(line[:80])}")
                
                if line.startswith("Content Type:"):
                    params['content_type'] = line.split(":", 1)[1].strip()
                elif line.startswith("Topic:"):
                    params['topic'] = line.split(":", 1)[1].strip()
                elif line.startswith("Word Limit:"):
                    params['word_limit'] = line.split(":",1)[1].strip()
                elif line.startswith("Audience/Tone:"):
                    params['audience_tone'] = line.split(":",1)[1].strip()
                elif line.startswith("Initial Outline/Concept:"):
                    params['outline_doc'] = line.split(":", 1)[1].strip()
                    if not params['outline_doc']:
                        i += 1
                        outline_lines = []
                        while i < len(lines):
                            next_line = lines[i]
                            if any(next_line.startswith(marker) for marker in 
                                   ["Content Type:", "Topic:", "Word Limit:", "Audience/Tone:", 
                                    "Supporting Documents:", "Additional Guidelines:", "Research Requested:"]):
                                break
                            if next_line.strip():
                                outline_lines.append(next_line)
                            i += 1
                        params['outline_doc'] = "\n".join(outline_lines)
                        i -= 1
                    else:
                        outline_lines = [params['outline_doc']]
                        i += 1
                        while i < len(lines):
                            next_line = lines[i]
                            if any(next_line.startswith(marker) for marker in 
                                   ["Content Type:", "Topic:", "Word Limit:", "Audience/Tone:", 
                                    "Supporting Documents:", "Additional Guidelines:", "Research Requested:"]):
                                break
                            if next_line.strip():
                                outline_lines.append(next_line)
                            i += 1
                        params['outline_doc'] = "\n".join(outline_lines)
                        i -= 1
                        
                elif line.startswith("Supporting Documents:"):
                    params['supporting_doc'] = line.split(":", 1)[1].strip()
                    if not params['supporting_doc']:
                        i += 1
                        supporting_lines = []
                        while i < len(lines):
                            next_line = lines[i]
                            if any(next_line.startswith(marker) for marker in 
                                   ["Content Type:", "Topic:", "Word Limit:", "Audience/Tone:", 
                                    "Initial Outline/Concept:", "Additional Guidelines:", "Research Requested:"]):
                                break
                            if next_line.strip():
                                supporting_lines.append(next_line)
                            i += 1
                        params['supporting_doc'] = "\n".join(supporting_lines)
                        i -= 1
                    else:
                        supporting_lines = [params['supporting_doc']]
                        i += 1
                        while i < len(lines):
                            next_line = lines[i]
                            if any(next_line.startswith(marker) for marker in 
                                   ["Content Type:", "Topic:", "Word Limit:", "Audience/Tone:", 
                                    "Initial Outline/Concept:", "Additional Guidelines:", "Research Requested:"]):
                                break
                            if next_line.strip():
                                supporting_lines.append(next_line)
                            i += 1
                        params['supporting_doc'] = "\n".join(supporting_lines)
                        i -= 1
                    
                i += 1
            
            logger.info(f"[PARSE] Parsed values - Content Type: '{params['content_type']}', Topic: '{params['topic']}', Word Limit: '{params['word_limit']}', Audience: '{params['audience_tone']}', Outline Doc : '{params['outline_doc']}', Supporting Doc: '{params['supporting_doc'][:500]}' ")
        
        return params
    
    async def conduct_research_with_graph(
        self,
        request: POVRequest,
        research_info: Dict[str, Any],
        topic: str
    ) -> str:
        """Conduct research using graph.py"""
        try:
            logger.info(f"[POV] Initializing graph.py for market intelligence research")
            
            # Build input data for graph.py
            input_data = {
                "research_topics": research_info['topics'] or topic or "Market trends and insights",
                "research_guidelines": research_info['additional_guidelines'] or "",
                "pwc_content": {},
                "proprietary": {},
                "thirdParty": {},
                "externalResearch": {}
            }
            
            # Add pwc_content if selected
            pwc_content = request.services.get('research', {}).get('pwc_content', {})
            if pwc_content.get('isSelected'):
                input_data["pwc_content"] = {
                    "isSelected": True,
                    "supportingDoc": pwc_content.get('supportingDoc', ''),
                    "supportingDoc_instructions": pwc_content.get('supportingDoc_instructions', ''),
                    "research_links": pwc_content.get('research_links', '')
                }
            
            # Add proprietary if selected
            proprietary = request.services.get('research', {}).get('proprietary', {})
            if proprietary.get('isSelected'):
                input_data["proprietary"] = {
                    "isSelected": True,
                    "sources": proprietary.get('sources', [])
                }

            # Add third party if selected
            thirdparty = request.services.get('research', {}).get('thirdParty', {})
            if thirdparty.get('isSelected'):
                input_data["thirdParty"] = {
                    "isSelected": True,
                    "sources": thirdparty.get('sources', [])
                }
            
            # Add externalResearch if selected
            external_research = request.services.get('research', {}).get('externalResearch', {})
            if external_research.get('isSelected'):
                input_data["externalResearch"] = {
                    "isSelected": True
                }
            
            logger.info(f"[POV] Calling graph.py with input: {json.dumps(input_data, default=str)}")
            
            # Get market insights from graph.py
            market_insights = get_market_insights(input_data)
            
            if market_insights:
                logger.info(f"[POV] Graph.py returned market insights {market_insights[:100]}")
                
                # Format the market insights into research context
                insights_text = json.dumps(market_insights, indent=2, default=str)
                research_context = f"""

--- Market Intelligence from Multi-Source Research ---
Research Sources:
- PwC Content & Documents
- PwC Proprietary Research Tools
- Licensed Third-Party Data Sources
- External Market Research

{insights_text}

--- End of Market Intelligence ---
"""
                logger.info("[POV] Market intelligence context added to research")
                return research_context
            else:
                logger.warning("[POV] Graph.py returned empty insights")
                return ""
                
        except Exception as e:
            logger.error(f"[POV] Graph.py error: {e}", exc_info=True)
            return ""
    
    async def conduct_research_with_langgraph(
        self,
        research_info: Dict[str, Any],
        topic: str
    ) -> str:
        """Conduct research using LangGraph agent"""
        try:
            logger.info(f"[POV] Initializing LangGraph Agent for multi-source query")
            
            # Create LangGraph agent instance
            langgraph_agent = create_data_source_agent(
                azure_endpoint=self.azure_endpoint,
                api_key=self.api_key,
                api_version=self.api_version,
                deployment_name=self.deployment_name
            )
            
            # Build the query message for the agent
            search_query = research_info['topics'] or topic
            if not search_query:
                logger.warning("[Meeting] LangGraph search_query is empty — provide 'topic' in the request or include 'Topic:' lines in the prompt")
            additional_guidelines = research_info.get('additional_guidelines') or ''
            logger.info(f"[Meeting][LangGraph] Query: {search_query}")
            agent_messages = [
                {
                    "role": "user",
                    "content": (
                        f"Research query: {search_query}\n\n"
                        "Please search relevant data sources and provide comprehensive information. "
                        "If a company name is present, include a Financial Overview retrieved from CapitalIQ: "
                        "YoY revenue, gross profit margin, recent stock performance, and a 3-year total shareholder return. "
                        "When returning the research, explicitly call the CapitalIQ tools (query_capitaliq_financials and query_capitaliq_balance_sheet) "
                        "for financial data, and include BoardEx for leadership info and Factiva for recent news. "
                        f"Refer {additional_guidelines}"
                    )
                }
            ]
            
            logger.info(f"[POV] Calling LangGraph Agent with query: {search_query}")
            
            # Get response from LangGraph agent
            agent_response = await langgraph_agent.process_query(agent_messages)
            
            if agent_response:
                logger.info(f"[POV] LangGraph Agent returned {len(agent_response)} characters")
                langgraph_context = f"""

--- Research Results from Multi-Source Data Integration ---
Sources automatically queried by AI Agent:
- Factiva News (external news and media coverage)
- Internal Knowledge Base (company documents and reports)
- CapitalIQ Financials (income statements and balance sheets)
- BoardEx Intelligence (advisors and executive achievements)
- Connected Sources
- Internet
{agent_response}

--- End of Research Results ---
"""
                logger.info("[POV] LangGraph Agent context added to research")
                langgraph_agent.close()
                return langgraph_context
            else:
                logger.warning("[POV] LangGraph Agent returned empty response")
                langgraph_agent.close()
                return ""
                
        except Exception as e:
            logger.error(f"[POV] LangGraph Agent error: {e}", exc_info=True)
            return ""
    
    def apply_word_limit_defaults(self, content_type: str, word_limit: str) -> tuple:
        """Apply default word limits based on content type"""
        word_limit_source = 'user'
        if not word_limit or not word_limit.strip():
            word_limit_source = 'default'
            # Set defaults based on content type (1000 words per page)
            if content_type == 'Perspective':
                word_limit = '2000'
            elif content_type == 'Blog':
                word_limit = '1500'
            elif content_type == 'Executive Brief':
                word_limit = '500'
            elif content_type == 'White Paper':
                word_limit = '5000'
            else:
                word_limit = '2000'
        
        # Convert word_limit to int and decrease by 30%
        try:
            word_limit_num = int(word_limit)
            word_limit_int = int(word_limit_num - (word_limit_num * 0.3))
        except (ValueError, TypeError):
            word_limit_int = 2000
            word_limit_source = 'default-conversion-failed'
            logger.warning(f"[POV] Failed to convert word_limit '{word_limit}' to int, using default 2000")
        
        return word_limit_int, word_limit_source
    
    async def generate_pov_content(
        self,
        request: POVRequest,
        user_prompt: str,
        is_improvement: bool
    ) -> StreamingResponse:
        """
        Generate complete POV content with research and streaming response
        
        Returns:
            StreamingResponse with the generated content
        """
        logger.info(f"[POV] Starting POV content generation")
        
        # Parse parameters
        params = self.parse_user_prompt(user_prompt, request)
        
        # For improvement iterations, use provided parameters
        if is_improvement and request.content_type:
            logger.info(f"[POV] Using preserved parameters for improvement iteration")
            params['content_type'] = request.content_type
            params['topic'] = request.topic or ''
            params['word_limit'] = request.word_limit or ''
            params['audience_tone'] = apply_audience_tone_defaults(params['content_type'], request.audience_tone)
            params['outline_doc'] = request.outline_doc or ''
            params['supporting_doc'] = request.supporting_doc or ''
            
            logger.info(f"[POV] Improvement iteration params - content_type='{params['content_type']}', topic='{params['topic']}', word_limit='{params['word_limit']}', audience='{params['audience_tone']}'")
        
        # Extract research information
        research_info = self.extract_research_info(user_prompt)
        enhanced_user_prompt = user_prompt
        langgraph_context = ""
        research_context = ""
        
        # Check if using graph.py for market intelligence research
        use_graph_py = False
        if request.services and request.services.get('research', {}).get('isSelected'):
            use_graph_py = True
            logger.info(f"[POV] Research service is selected - using graph.py for market intelligence")
        
        # Handle Multi-Source Research Integration
        if use_graph_py:
            research_context = await self.conduct_research_with_graph(
                request=request,
                research_info=research_info,
                topic=params['topic']
            )
        
        # Always use LangGraph Agent
        if True:
            langgraph_context = await self.conduct_research_with_langgraph(
                research_info=research_info,
                topic=params['topic']
            )
        
        # Apply default word limits
        word_limit_int, word_limit_source = self.apply_word_limit_defaults(
            params['content_type'],
            params['word_limit']
        )
        
        # Apply default audience/tone
        audience_tone = apply_audience_tone_defaults(params['content_type'], params['audience_tone'])
        
        logger.info(f"[POV] Analytics - content_type={params['content_type']}, word_limit_source={word_limit_source}, word_limit_value={word_limit_int}")
        
        # Use improvement prompt if this is an improvement iteration
        final_prompt = enhanced_user_prompt
        if is_improvement and params['original_generated_content']:
            final_prompt = self.build_improvement_prompt(enhanced_user_prompt, request.improvement_prompt, params['original_generated_content'])
            logger.info(f"[CONTENT GENERATION] Using improvement prompt (original content: {len(params['original_generated_content'])} chars)")
        
        # Add LangGraph context if available
        if langgraph_context:
            params['supporting_doc'] += langgraph_context
        
        # Generate content based on content type
        if params['content_type'] == 'Article':
            return StreamingResponse(
                self.pov_service.pov_article_system_prompt(
                    final_prompt, params['topic'], word_limit_int, audience_tone, 
                    params['outline_doc'], params['supporting_doc'], research_context
                ),
                media_type="text/event-stream",
                headers={"X-Content-Type": params['content_type']}
            )
        elif params['content_type'] == 'Blog':
            return StreamingResponse(
                self.pov_service.pov_blog_system_prompt(
                    final_prompt, params['topic'], word_limit_int, audience_tone, 
                    params['outline_doc'], params['supporting_doc'], research_context
                ),
                media_type="text/event-stream",
                headers={"X-Content-Type": params['content_type']}
            )
        elif params['content_type'] == 'Executive Brief':
            return StreamingResponse(
                self.pov_service.pov_executivebrief_system_prompt(
                    final_prompt, params['topic'], word_limit_int, audience_tone, 
                    params['outline_doc'], params['supporting_doc'], research_context
                ),
                media_type="text/event-stream",
                headers={"X-Content-Type": params['content_type']}
            )
        else:
            return StreamingResponse(
                self.pov_service.pov_content_from_prompt(final_prompt, research_context),
                media_type="text/event-stream"
            )


router = APIRouter()

@router.post("")
async def pov_workflow(
    request: POVRequest,
    service: POVService = Depends(get_tl_service(POVService)),
    factiva_client: Optional[FactivaClient] = Depends(get_factiva_client),
    settings: Settings = Depends(get_settings)
):
    """POV workflow"""
    try:
        user_prompt = request.messages[-1].get("content", "") if request.messages else ""
        
        logger.info(f"[POV] User prompt length: {len(user_prompt)}")
        logger.debug(f"[POV] Full user prompt:\n{user_prompt}")

        # Check if this is an improvement request
        is_improvement = POVResearchService.is_improvement_request(request.improvement_prompt)
        if is_improvement:
            logger.info(f"[POV] Improvement request detected")
            logger.info(f"[POV] Improvement feedback: {request.improvement_prompt}")
        
        # Initialize research service
        research_service = POVResearchService(
            pov_service=service,
            azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
            api_key=config.AZURE_OPENAI_API_KEY,
            api_version=config.AZURE_OPENAI_API_VERSION,
            deployment_name=config.AZURE_OPENAI_DEPLOYMENT
        )
        
        # Generate POV content with research
        return await research_service.generate_pov_content(
            request=request,
            user_prompt=user_prompt,
            is_improvement=is_improvement
        )
        
    except Exception as e:
        logger.error(f"[POV] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))