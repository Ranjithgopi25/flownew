from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from fastapi.responses import StreamingResponse
from typing import Optional, Union, Dict, Any
from app.core.deps import get_llm_service, create_chat_history_context
from app.infrastructure.llm.llm_service import LLMService
from app.features.ddc.agents.sanitization_agent import SanitizationAgent
from app.features.ddc.services.sanitization.utils import SanitizationService
from app.features.ddc.services.slide_creation_service import PlusDocsClient
import logging
import uuid
import asyncio
from datetime import datetime, timedelta
from fastapi.responses import JSONResponse, Response
from app.core.config import config
from app.core.redis_client import cache
import json
import base64

router = APIRouter()
logger = logging.getLogger(__name__)

# Fallback: In-memory storage when Redis is unavailable
conversation_storage: Dict[str, Dict[str, Any]] = {}

REDIS_KEY_PREFIX = "ddc_chat"
REDIS_EXPIRY = 7200  # 2 hours


def get_redis_key(conversation_id: str) -> str:
    """Generate Redis key for conversation."""
    return f"{REDIS_KEY_PREFIX}:{conversation_id}"


def get_conversation_data(conversation_id: str) -> Dict[str, Any]:
    """Get conversation data from Redis with fallback to memory."""
    default_data = {
        'timestamp': datetime.now().isoformat(),
        'file_data': None,
        'file_name': None,
        'custom_template_data': None,
        'custom_template_name': None,
        'conversation_history': []
    }
    
    redis_key = get_redis_key(conversation_id)
    
    # Try Redis first
    try:
        logger.info(f"[Redis] Attempting to get conversation data for key: {redis_key}")
        data = cache.get_json(redis_key)
        
        if data:
            logger.info(f"[Redis] Successfully retrieved data for {conversation_id}")
            # Decode file_data from base64 if present
            if data.get('file_data'):
                try:
                    data['file_data'] = base64.b64decode(data['file_data'])
                    logger.info(f"[Redis] Decoded file_data for {conversation_id}")
                except Exception as e:
                    logger.error(f"[Redis] Failed to decode file_data: {e}")
                    data['file_data'] = None
            return data
        else:
            logger.info(f"[Redis] No data found for {conversation_id}, returning default")
            return default_data
            
    except Exception as e:
        logger.error(f"[Redis] Error getting conversation data: {e}", exc_info=True)
        logger.info(f"[Fallback] Using in-memory storage for {conversation_id}")
        
        # Fallback to memory
        if conversation_id in conversation_storage:
            logger.info(f"[Fallback] Found data in memory for {conversation_id}")
            return conversation_storage[conversation_id]
        else:
            logger.info(f"[Fallback] No data in memory, returning default for {conversation_id}")
            return default_data


def save_conversation_data(conversation_id: str, data: Dict[str, Any]) -> bool:
    """Save conversation data to Redis with fallback to memory."""
    redis_key = get_redis_key(conversation_id)
    
    # Prepare data for storage
    save_data = data.copy()
    save_data['timestamp'] = datetime.now().isoformat()
    
    # Try Redis first
    try:
        logger.info(f"[Redis] Attempting to save conversation data for key: {redis_key}")
        
        # Encode file_data to base64 for JSON storage
        if save_data.get('file_data'):
            try:
                save_data['file_data'] = base64.b64encode(save_data['file_data']).decode('utf-8')
                logger.info(f"[Redis] Encoded file_data for {conversation_id}")
            except Exception as e:
                logger.error(f"[Redis] Failed to encode file_data: {e}")
                save_data['file_data'] = None
        
        success = cache.set_json(redis_key, save_data, ex=REDIS_EXPIRY)
        
        if success:
            logger.info(f"[Redis] Successfully saved data for {conversation_id} with {REDIS_EXPIRY}s expiry")
            return True
        else:
            logger.warning(f"[Redis] Failed to save data for {conversation_id}")
            raise Exception("Redis set_json returned False")
            
    except Exception as e:
        logger.error(f"[Redis] Error saving conversation data: {e}", exc_info=True)
        logger.info(f"[Fallback] Saving to in-memory storage for {conversation_id}")
        
        # Fallback to memory (restore original file_data if it was encoded)
        fallback_data = data.copy()
        fallback_data['timestamp'] = datetime.now()
        conversation_storage[conversation_id] = fallback_data
        logger.info(f"[Fallback] Successfully saved to memory for {conversation_id}")
        return False


def cleanup_old_conversations():
    """Remove conversations older than 2 hours from memory (Redis auto-expires)."""
    try:
        logger.info("[Cleanup] Starting cleanup of old in-memory conversations")
        cutoff = datetime.now() - timedelta(hours=2)
        to_delete = []
        
        for conv_id, data in conversation_storage.items():
            timestamp = data.get('timestamp')
            
            # Handle both string (ISO format) and datetime objects
            if isinstance(timestamp, str):
                try:
                    timestamp_dt = datetime.fromisoformat(timestamp)
                except (ValueError, TypeError):
                    logger.warning(f"[Cleanup] Invalid timestamp format for {conv_id}: {timestamp}")
                    timestamp_dt = datetime.now()
            elif isinstance(timestamp, datetime):
                timestamp_dt = timestamp
            else:
                logger.warning(f"[Cleanup] Unknown timestamp type for {conv_id}: {type(timestamp)}")
                timestamp_dt = datetime.now()
            
            if timestamp_dt < cutoff:
                to_delete.append(conv_id)
        
        for conv_id in to_delete:
            del conversation_storage[conv_id]
            logger.info(f"[Cleanup] Removed in-memory conversation: {conv_id}")
        
        if to_delete:
            logger.info(f"[Cleanup] Removed {len(to_delete)} old conversations from memory")
        else:
            logger.info("[Cleanup] No old conversations to remove from memory")
            
    except Exception as e:
        logger.error(f"[Cleanup] Error during cleanup: {e}", exc_info=True)


@router.post("")
async def ddc_chat_agent(
    message: str = Form(...),
    conversation_id: Optional[str] = Form(None),
    file: Optional[UploadFile] = File(None),
    user_id: Optional[str] = Form(None),
    session_id: Optional[str] = Form(None),
    source: Optional[str] = Form(None),
    llm_service: LLMService = Depends(get_llm_service)
):
    """DDC Chat Agent: Conversational interface for DDC workflows"""
    try:
        # Cleanup old in-memory conversations
        cleanup_old_conversations()
        
        # Use provided conversation_id or generate new one
        if not conversation_id or conversation_id == "none":
            conversation_id = f"session_{uuid.uuid4().hex[:8]}"
            logger.info(f"[DDC Chat Agent] Generated new conversation_id: {conversation_id}")
        
        # Use conversation_id as session_id if not provided
        if not session_id:
            session_id = conversation_id
        
        # Initialize chat history context for manual saving
        chat_history = None
        if user_id and session_id:
            chat_history = create_chat_history_context(
                user_id=user_id,
                session_id=session_id,
                source=source or "DDDC"
            )
            logger.info(f"[DDC Chat Agent] Chat history enabled for session {session_id}")
        
        logger.info(f"[DDC Chat Agent] Processing message for conversation: {conversation_id}")
        logger.info(f"[DDC Chat Agent] Message: {message[:100]}...")  # Log first 100 chars
        
        # Get conversation data from Redis (or fallback to memory)
        stored_data = get_conversation_data(conversation_id)
        logger.info(f"[DDC Chat Agent] Retrieved stored data for {conversation_id}")
        
        # Store new file if provided
        if file and file.filename:
            logger.info(f"[DDC Chat Agent] New file uploaded: {file.filename}")
            try:
                file_data = await file.read()
                stored_data['file_data'] = file_data
                stored_data['file_name'] = file.filename
                logger.info(f"[DDC Chat Agent] File data read successfully: {len(file_data)} bytes")
            except Exception as e:
                logger.error(f"[DDC Chat Agent] Error reading file: {e}", exc_info=True)
                raise HTTPException(status_code=400, detail=f"Failed to read file: {str(e)}")
        
        # Retrieve stored data
        file_data = stored_data.get('file_data')
        file_name = stored_data.get('file_name')
        conversation_history = stored_data.get('conversation_history', [])
        
        logger.info(f"[DDC Chat Agent] File in context: {file_name if file_name else 'None'}")
        logger.info(f"[DDC Chat Agent] Conversation history length: {len(conversation_history)}")
        
        # Add user message to history
        conversation_history.append({
            'role': 'user',
            'content': message,
            'timestamp': datetime.now().isoformat()
        })
        logger.info(f"[DDC Chat Agent] Added user message to history")

        # Initialize services
        try:
            sanitization_service = SanitizationService(llm_service)
            ppt_service = PlusDocsClient(api_token=config.PLUSDOCS_API_TOKEN)
            agent = SanitizationAgent(llm_service, sanitization_service, ppt_service)
            logger.info(f"[DDC Chat Agent] Services initialized successfully")
        except Exception as e:
            logger.error(f"[DDC Chat Agent] Error initializing services: {e}", exc_info=True)
            raise HTTPException(status_code=500, detail=f"Failed to initialize services: {str(e)}")
        
        # Process message
        try:
            logger.info(f"[DDC Chat Agent] Processing message with agent")
            result = await agent.process_message_sync(
                message=message,
                conversation_id=conversation_id,
                file_data=file_data,
                file_name=file_name,
                conversation_history=conversation_history
            )
            logger.info(f"[DDC Chat Agent] Agent processing completed successfully")
        except Exception as e:
            logger.error(f"[DDC Chat Agent] Error processing message: {e}", exc_info=True)
            raise HTTPException(status_code=500, detail=f"Failed to process message: {str(e)}")
        
        # Add agent response to history
        assistant_message = result.get("message", "")
        conversation_history.append({
            'role': 'assistant',
            'content': assistant_message,
            'timestamp': datetime.now().isoformat()
        })
        logger.info(f"[DDC Chat Agent] Added assistant message to history")
        
        # Update conversation history in storage
        stored_data['conversation_history'] = conversation_history
        save_success = save_conversation_data(conversation_id, stored_data)
        
        if save_success:
            logger.info(f"[DDC Chat Agent] Conversation data saved to Redis")
        else:
            logger.info(f"[DDC Chat Agent] Conversation data saved to memory (fallback)")
        
        # Save assistant response to chat history (fire-and-forget)
        if chat_history and chat_history.enabled and assistant_message:
            try:
                asyncio.create_task(
                    chat_history.helper.save_assistant_message(assistant_message)
                )
                logger.info(f"[DDC Chat Agent] Queued assistant response for chat history")
            except Exception as e:
                logger.error(f"[DDC Chat Agent] Error queueing chat history save: {e}")
        
        # If file was sanitized, return it
        if result.get("file_bytes"):
            logger.info(f"[DDC Chat Agent] Returning sanitized file")
            output_filename = file_name.replace('.pptx', '_sanitized.pptx')
            summary = result.get("summary", {})
            
            if summary:
                summary_text = ", ".join(
                    f"{k.replace('_', ' ').title()}: {v}"
                    for k, v in summary.items()
                )
            else:
                summary_text = "No sanitization changes were required."

            agent_message = (
                "Sanitization completed successfully. "
                f"{summary_text}"
            )
            
            logger.info(f"[DDC Chat Agent] File response prepared: {output_filename}")
            
            return Response(
                content=result["file_bytes"],
                media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
                headers={
                    "Content-Disposition": f'attachment; filename="{output_filename}"',
                    "X-Agent-Message": agent_message,
                    "X-Conversation-ID": conversation_id,
                }
            )
        
        # If no file, return JSON message only
        logger.info(f"[DDC Chat Agent] Returning JSON response")
        return JSONResponse(
            content={
                "message": assistant_message,
                "conversation_id": conversation_id
            },
            headers={
                "X-Conversation-ID": conversation_id
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[DDC Chat Agent] Unexpected error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))