from langchain_core.tools import tool
from typing import Dict, Any, Optional, List
import json
import logging
from app.core.config import config
from app.features.ddc.utils.text_refiner import extract_meaning_from_image

logger = logging.getLogger(__name__)

@tool
def generate_powerpoint_presentation(
    user_request: str,
    enhanced_guidelines: Optional[str] = None,
    ppt_service = None
    
) -> str:
    """
    Generate a PowerPoint presentation based on user request.
    
    Use this tool when the user asks to:
    - Create a PowerPoint presentation
    - Generate a PPT or deck
    - Prepare slides
    - Make a presentation
    
    Args:
        user_request: The original user request/query
        enhanced_guidelines: Optional enhanced version with more details
        ppt_service: PPT service instance (injected at runtime)        
    
    Returns:
        Displays exact message to user.
        Does not ask for additional revisions or details, gives straightforward response.
        
    """
    if not ppt_service:
        return "PPT service not available"
    
    isImage_bool = False
    logger.info(f"Main user request from frontend: {user_request}")
    user_request_re = user_request

    if "<image_data>" in user_request:
        #imageData = user_request.split("<image_data>")[1]
        isImage_bool = True
        user_request_re = user_request.split("<image_data>")[0]        
        imageData = user_request.split("<image_data>")[1].split("<image_ext>")[0]
        imageExt = user_request.split("<image_ext>")[1]
        image_meaning = extract_meaning_from_image(imageData, imageExt)
        user_request_re = user_request_re + "\nImage details to be used to generate the slide: " + image_meaning

    # elif "<xlsx_data>" in user_request:
    #     xlsxData = user_request.split("<xlsx_data>")[1]
    #     user_request_re = user_request.split("<xlsx_data>")[0]
    #     user_request_re = user_request_re + "\nWhile creating this presentation use this chart data" + xlsxData + "to build graphs or charts. Make sure to create a visual which properly explains the data."
    #     isImage_bool = False
    
    elif "<xlsx_data>" in user_request and "</xlsx_data>" in user_request:
        before, rest = user_request.split("<xlsx_data>", 1)
        xlsxData, after = rest.split("</xlsx_data>", 1)

        #logger.info(f"chart data: {xlsxData}")

        user_request_re = before + after
        user_request_re = user_request_re + "\nWhile creating this presentation use this chart data" + xlsxData + "to build graphs or charts. Make sure to create a visual which properly explains the data."

        isImage_bool = False
#enhanced_guidelines or 

    logger.info(f"data to plus ai: {user_request_re}")
    download_url = ppt_service.create_and_wait(
        prompt=user_request_re,
        template_id=config.PLUSDOCS_TEMPLATE_ID,
        isImage=isImage_bool
    )

    if download_url:
        html_text = f"""Please click <a href="{download_url}" target="_blank" rel="noopener noreferrer">here</a>to download your presentation."""
    else:
        html_text = "✗ Failed to generate presentation."

    return html_text
    #return f" Presentation ready: {download_url}" if download_url else "✗ Failed"
@tool
async def sanitize_presentation(
    services: List[str],
    additional_guidelines: str = "",
    file_data: bytes = None,
    file_name: str = None,
    sanitization_service = None,
    llm_service = None
) -> Dict[str, Any]:
    """
    Sanitize a PowerPoint presentation using the PPTSanitizer graph.
    
    This is a thin wrapper that delegates all work to the sanitization graph.
    
    Args:
        services: List of service IDs (e.g., ["replace_client", "delete_notes"])
        additional_guidelines: Optional natural language instructions for sanitization
        file_data: File bytes (injected by agent)
        file_name: File name (injected by agent)
        sanitization_service: Service instance (injected by agent)
        llm_service: LLM service (injected by agent)
    
    Returns:
        Dict with status, file data, and sanitization stats
    """
    try:
        logger.info(f"[Tool] Sanitizing: {file_name} with services: {services}")
        
        if not file_data or not file_name:
            return {
                "status": "error",
                "message": "File data and filename are required"
            }
        
        if not sanitization_service:
            return {
                "status": "error",
                "message": "Sanitization service not available"
            }
        
        # Delegate everything to the graph-based service
        sanitized_bytes, plan = await sanitization_service.sanitize_presentation(
            ppt_bytes=file_data,
            filename=file_name,
            selected_services=services,
            client_identifiers="",
            template="core",
            template_bytes=None,
            llm_service=llm_service,
            additional_guidelines=additional_guidelines if additional_guidelines else None
        )
        
        return {
            "status": "success",
            "file_size": len(sanitized_bytes),
            "file_name": file_name.replace('.pptx', '_sanitized.pptx'),
            "file_data_base64": sanitized_bytes.hex(),
            "summary": plan.get('summary', {}),
            "plan": plan.get('items', [])
        }
        
    except Exception as e:
        logger.error(f"[Tool] Sanitization error: {e}", exc_info=True)
        return {
            "status": "error",
            "message": str(e)
        }
def get_all_tools():
    """Return list of all available tools."""
    return [
        generate_powerpoint_presentation,
        sanitize_presentation
    ]