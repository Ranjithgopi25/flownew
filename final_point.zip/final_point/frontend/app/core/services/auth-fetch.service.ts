import { Injectable, OnDestroy } from '@angular/core';
import { MsalService } from '@azure/msal-angular';
import { environment } from '../../../environments/environment';
import { AuthService } from '../../auth/auth.service';
import { InteractionRequiredAuthError } from '@azure/msal-browser';

/**
 * Centralized helper for authenticated fetch() calls.
 * - Use authenticatedFetch for JSON requests
 * - Use authenticatedFetchFormData for FormData uploads
 * - Automatically refreshes token every 55 minutes
 */
@Injectable({
  providedIn: 'root'
})
export class AuthFetchService implements OnDestroy {
  private tokenRefreshTimer: any = null;
  private readonly TOKEN_REFRESH_INTERVAL =55 * 60 * 1000; // 55 minutes
  private isRefreshCycleStarted = false;
  private refreshAttemptCount = 0;

  constructor(private msalService: MsalService, private authService: AuthService) {
    console.log('[AuthFetchService] 🔧 Service initialized');
  }

  /**
   * Initialize token refresh cycle (call this from app.component.ts after login)
   */
  public initializeTokenRefresh(): void {
    console.log('[AuthFetchService] 🚀 initializeTokenRefresh() called');
    console.log('[AuthFetchService] 📊 Current state - useAuth:', environment.useAuth, 'isRefreshCycleStarted:', this.isRefreshCycleStarted);

    if (!environment.useAuth) {
      console.log('[AuthFetchService] ⚠️ Auth is disabled in environment, skipping token refresh initialization');
      return;
    }

    if (this.isRefreshCycleStarted) {
      console.log('[AuthFetchService] ⚠️ Token refresh cycle already started, skipping duplicate initialization');
      return;
    }

    this.isRefreshCycleStarted = true;
    console.log('[AuthFetchService] ✅ Token refresh cycle started');

    // Refresh immediately on initialization
    console.log('[AuthFetchService] 🔄 Performing initial token refresh...');
    this.silentTokenRefresh();

    // Set up periodic refresh every 55 minutes
    this.tokenRefreshTimer = setInterval(() => {
      console.log('[AuthFetchService] ⏰ Periodic token refresh triggered (55 min interval)');
      this.silentTokenRefresh();
    }, this.TOKEN_REFRESH_INTERVAL);

    console.log('[AuthFetchService] ⏲️ Token refresh timer set - will refresh every', this.TOKEN_REFRESH_INTERVAL / 1000 / 60, 'minutes');
  }

  /**
   * Stop token refresh cycle
   */
  public stopTokenRefresh(): void {
    console.log('[AuthFetchService] 🛑 stopTokenRefresh() called');
    
    if (this.tokenRefreshTimer) {
      clearInterval(this.tokenRefreshTimer);
      this.tokenRefreshTimer = null;
      this.isRefreshCycleStarted = false;
      console.log('[AuthFetchService] ✅ Token refresh cycle stopped and timer cleared');
    } else {
      console.log('[AuthFetchService] ℹ️ No active refresh timer to stop');
    }
  }

  /**
   * Silently refreshes the access token using MSAL
   */
  private async silentTokenRefresh(): Promise<void> {
    this.refreshAttemptCount++;
    console.log('[AuthFetchService] 🔄 silentTokenRefresh() attempt #', this.refreshAttemptCount);

    if (!environment.useAuth) {
      console.log('[AuthFetchService] ⚠️ Auth disabled, skipping refresh');
      return;
    }

    try {
      const account = this.msalService.instance.getActiveAccount();
      console.log('[AuthFetchService] 👤 Active account check:', account ? `Found (${account.username})` : 'No active account');

      if (!account) {
        console.log('[AuthFetchService] ❌ No active account found, cannot refresh token');
        return;
      }

      console.log('[AuthFetchService] 🔐 Calling acquireTokenSilent with forceRefresh=true...');
      const startTime = Date.now();
      
      const result = await this.msalService.instance.acquireTokenSilent({
        scopes: ['User.Read'],
        account,
        forceRefresh: true
      });

      const duration = Date.now() - startTime;
      console.log('[AuthFetchService] ⏱️ Token acquisition took', duration, 'ms');

      if (result?.idToken) {
        console.log('[AuthFetchService] ✅ Token refreshed successfully');
        console.log('[AuthFetchService] 📅 Token expiration:', new Date(result.expiresOn || 0).toLocaleString());
      } else {
        console.warn('[AuthFetchService] ⚠️ Token refresh completed but no idToken returned');
      }
    } catch (error: any) {
      console.error('[AuthFetchService] ❌ Silent token refresh failed:', error);
      console.error('[AuthFetchService] 📋 Error details - Type:', error?.constructor?.name, 'Message:', error?.message);
      
      // Check if error requires interaction
      if (error instanceof InteractionRequiredAuthError) {
        console.log('[AuthFetchService] 🔓 InteractionRequiredAuthError detected - user interaction needed');
        console.log('[AuthFetchService] 🔄 Attempting redirect to login...');
        
        try {
          await this.msalService.instance.acquireTokenRedirect({
            scopes: ['User.Read']
          });
          console.log('[AuthFetchService] ✅ Redirect initiated successfully');
        } catch (redirectError) {
          console.error('[AuthFetchService] ❌ Redirect to login failed:', redirectError);
          console.log('[AuthFetchService] 🛑 Stopping refresh cycle and logging out user');
          this.stopTokenRefresh();
          this.authService.logout();
        }
      } else {
        console.log('[AuthFetchService] ℹ️ Non-interaction error, will retry at next interval');
      }
    }
  }

  private async acquireAccessToken(): Promise<string | null> {
    console.log('[AuthFetchService] 🔑 acquireAccessToken() called');
    
    if (!environment.useAuth) {
      console.log('[AuthFetchService] ⚠️ Auth disabled, returning null token');
      return null;
    }

    try {
      const account = this.msalService.instance.getActiveAccount();
      
      if (!account) {
        console.log('[AuthFetchService] ❌ No active account in acquireAccessToken');
        return null;
      }

      console.log('[AuthFetchService] 🔐 Acquiring token silently for:', account.username);
      
      const result = await this.msalService.instance.acquireTokenSilent({
        scopes: ['User.Read'],
        account
      });

      if (result?.idToken) {
        console.log('[AuthFetchService] ✅ Access token acquired successfully');
        return result.idToken;
      } else {
        console.warn('[AuthFetchService] ⚠️ Token result has no idToken');
        return null;
      }
    } catch (error: any) {
      console.error('[AuthFetchService] ❌ acquireAccessToken failed:', error?.message);
      
      // Try interactive acquisition if needed
      if (error instanceof InteractionRequiredAuthError) {
        console.log('[AuthFetchService] 🔓 Attempting interactive token acquisition via popup...');
        try {
          const account = this.msalService.instance.getActiveAccount();
          if (account) {
            const result = await this.msalService.instance.acquireTokenPopup({
              scopes: ['User.Read'],
              account
            });
            console.log('[AuthFetchService] ✅ Interactive token acquisition succeeded');
            return result?.idToken ?? null;
          }
        } catch (popupError: any) {
          console.error('[AuthFetchService] ❌ Interactive token acquisition failed:', popupError?.message);
        }
      }
      
      return null;
    }
  }

  /** JSON requests - sets Content-Type and Authorization (if available) */
  async authenticatedFetch(url: string, options: RequestInit = {}): Promise<Response> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string> || {})
    };

    const token = await this.acquireAccessToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    console.log('[AuthFetchService] authenticatedFetch - URL:', url, 'Has Authorization:', !!headers['Authorization']);

    const response = await fetch(url, {
      ...options,
      headers
    });

    // If backend rejects authorization for fetch-based requests, trigger logout
    if (response && (response.status === 401 || response.status === 403)) {
      console.error('[AuthFetchService] Fetch returned auth error:', response.status, 'for', url);
      try {
        this.authService.logout();
      } catch (e) {
        console.error('[AuthFetchService] Failed to invoke logout on auth error', e);
      }
    }

    return response;
  }

  /** FormData requests - do not set Content-Type (browser will set boundary) */
  async authenticatedFetchFormData(url: string, options: RequestInit = {}): Promise<Response> {
    const headers: Record<string, string> = {
      ...(options.headers as Record<string, string> || {})
    };

    const token = await this.acquireAccessToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    console.log('[AuthFetchService] authenticatedFetchFormData - URL:', url, 'Has Authorization:', !!headers['Authorization']);

    const response = await fetch(url, {
      ...options,
      headers
    });

    if (response && (response.status === 401 || response.status === 403)) {
      console.error('[AuthFetchService] Fetch FormData returned auth error:', response.status, 'for', url);
      try {
        this.authService.logout();
      } catch (e) {
        console.error('[AuthFetchService] Failed to invoke logout on auth error', e);
      }
    }

    return response;
  }

  /**
   * Clean up timer when service is destroyed
   */
  ngOnDestroy(): void {
    console.log('[AuthFetchService] 🧹 ngOnDestroy() called - cleaning up');
    this.stopTokenRefresh();
  }
}
