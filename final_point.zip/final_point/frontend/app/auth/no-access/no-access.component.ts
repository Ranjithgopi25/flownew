import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-no-access',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="no-access-container">
      <div class="no-access-box">
        <div class="no-access-icon">
          <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="15" y1="9" x2="9" y2="15"></line>
            <line x1="9" y1="9" x2="15" y2="15"></line>
          </svg>
        </div>
        <h1>Access Denied</h1>
        <p class="message">You do not have permission to access this application.</p>
        <p class="submessage">Your email address is not on the authorized users list. Please contact your administrator for access.</p>
        
        <div class="user-info">
          <p><strong>Your Email:</strong> {{ userEmail }}</p>
        </div>

        <button class="logout-btn" (click)="logout()">
          <span>Logout</span>
        </button>
      </div>
    </div>
  `,
  styles: [`
    .no-access-container {
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      background: #FFE8D4;
      font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
    }

    .no-access-box {
      background: white;
      border-radius: 12px;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
      padding: 3rem 2.5rem;
      max-width: 500px;
      text-align: center;
    }

    .no-access-icon {
      margin-bottom: 1.5rem;
      color: #ef4444;
    }

    h1 {
      font-size: 2rem;
      color: #1f2937;
      margin: 0 0 1rem 0;
      font-weight: 600;
    }

    .message {
      font-size: 1.1rem;
      color: #4b5563;
      margin: 0 0 0.5rem 0;
      line-height: 1.6;
    }

    .submessage {
      font-size: 0.95rem;
      color: #6b7280;
      margin: 0.5rem 0 1.5rem 0;
      line-height: 1.5;
    }

    .user-info {
      background: #f3f4f6;
      border-left: 4px solid #FD5108;
      padding: 1rem;
      margin-bottom: 2rem;
      border-radius: 6px;
      text-align: left;
    }

    .user-info p {
      margin: 0;
      font-size: 0.95rem;
      color: #374151;
    }

    .logout-btn {
      background-color: #FD5108;
      color: white;
      border: none;
      padding: 0.75rem 2rem;
      font-size: 1rem;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 500;
      transition: background-color 0.2s ease, transform 0.1s ease;
      width: 100%;
    }

    .logout-btn:hover {
      background-color: #B83E02;
      transform: translateY(-2px);
    }

    .logout-btn:active {
      transform: translateY(0);
    }
  `]
})
export class NoAccessComponent {
  userEmail: string = '';

  constructor(private authService: AuthService) {
    const userInfo = this.authService.getUserInfo();
    this.userEmail = userInfo?.email || 'Unknown';
  }

  logout(): void {
    this.authService.logout();
  }
}
