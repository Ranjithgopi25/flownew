import { Injectable } from '@angular/core';

export interface WorkflowConfig {
  id: string;
  name: string;
  description: string;
  category: 'ddc' | 'thought-leadership' | 'market-intelligence';
  icon: string;
  route?: string;
  keywords: string[];
}

@Injectable({
  providedIn: 'root'
})
export class WorkflowRegistryService {
  private workflows: Map<string, WorkflowConfig> = new Map();

  constructor() {
    this.registerDefaultWorkflows();
  }

  private registerDefaultWorkflows(): void {
    const ddcWorkflows: WorkflowConfig[] = [
      {
        id: 'brand-format',
        name: 'Brand & Formatting',
        description: 'Convert to PwC template, rebrand colors, ensure consistency',
        category: 'ddc',
        icon: 'palette',
        keywords: ['brand', 'format', 'template', 'rebrand', 'formatting']
      },
      {
        id: 'professional-polish',
        name: 'Professional Polish',
        description: 'Grammar check, visual design improvements, consistency',
        category: 'ddc',
        icon: 'sparkles',
        keywords: ['polish', 'grammar', 'professional', 'design']
      },
      {
        id: 'sanitization',
        name: 'Presentation Sanitization',
        description: 'Remove client-specific information with tier-based privacy',
        category: 'ddc',
        icon: 'shield',
        keywords: ['sanitize', 'sanitization', 'privacy', 'clean', 'scrub']
      },
      {
        id: 'client-customization',
        name: 'New Client Customization',
        description: 'Customize branding, colors, and messaging for new clients',
        category: 'ddc',
        icon: 'users',
        keywords: ['client', 'customize', 'customization', 'branding']
      },
      {
        id: 'rfp-response',
        name: 'RFP Response',
        description: 'Align presentation with RFP requirements',
        category: 'ddc',
        icon: 'document',
        keywords: ['rfp', 'proposal', 'response', 'alignment']
      },
      {
        id: 'ddc-format-translator',
        name: 'DDC Format Translator',
        description: 'Convert PPTX to case studies, podcasts, or blogs',
        category: 'ddc',
        icon: 'refresh',
        keywords: ['convert', 'translate', 'format', 'case study']
      },
      {
        id: 'slide-creation',
        name: 'Slide Creation',
        description: 'Generate AI-powered slide outlines from document',
        category: 'ddc',
        icon: 'plus',
        keywords: ['create', 'slide', 'generate', 'outline']
      },
      {
        id: 'slide-creation-prompt',
        name: 'Slide Creation Prompt',
        description: 'Generate AI-powered slide outlines from prompt',
        category: 'ddc',
        icon: 'plus',
        keywords: ['create', 'slide', 'generate', 'outline', 'prompt']
      }

    ];

    const tlWorkflows: WorkflowConfig[] = [
      {
        id: 'draft-content',
        name: 'Draft Content',
        description: 'Create articles, blogs, white papers, or podcasts',
        category: 'thought-leadership',
        icon: 'edit',
        keywords: ['draft', 'create', 'article', 'blog', 'white paper', 'podcast', 'write']
      },
      {
        id: 'conduct-research',
        name: 'Conduct Research',
        description: 'Multi-document synthesis with citations',
        category: 'thought-leadership',
        icon: 'search',
        keywords: ['research', 'synthesize', 'citations', 'sources']
      },
      {
        id: 'edit-content',
        name: 'Edit Content',
        description: 'Brand alignment, copy editing, content refinement',
        category: 'thought-leadership',
        icon: 'check',
        keywords: ['edit', 'refine', 'improve', 'align']
      },
      {
        id: 'refine-content',
        name: 'Refine Content',
        description: 'Expand, compress, adjust tone, enhance research',
        category: 'thought-leadership',
        icon: 'tune',
        keywords: ['refine', 'optimize', 'tone', 'expand', 'compress']
      },
      {
        id: 'format-translator',
        name: 'Format Translator',
        description: 'Convert between content formats',
        category: 'thought-leadership',
        icon: 'transform',
        keywords: ['convert', 'translate', 'format', 'transform']
      },
      {
        id: 'generate-podcast',
        name: 'Generate Podcast',
        description: 'Create audio podcasts with AI-generated dialogue',
        category: 'thought-leadership',
        icon: 'microphone',
        keywords: ['podcast', 'audio', 'generate', 'dialogue', 'monologue']
      }
    ];

    const miWorkflows: WorkflowConfig[] = [
      {
        id: 'conduct-research',
        name: 'Conduct Research',
        description: 'Multi-document synthesis with citations',
        category: 'market-intelligence',
        icon: 'search',
        keywords: ['research', 'synthesize', 'citations', 'sources']
      },
      {
        id: 'create-pov',
        name: 'Create POV',
        description: 'Create a point of view for market intelligence',
        category: 'market-intelligence',
        icon: 'check',
        keywords: ['create', 'refine', 'improve', 'align']
      },
      {
        id: 'prepare-client-meeting',
        name: 'Prepare for Client Meeting',
        description: 'Prepare, client, schedule, meeting',
        category: 'market-intelligence',
        icon: 'tune',
        keywords: ['prepare', 'optimize', 'client', 'expand', 'meeting']
      },
      {
        id: 'gather-proposal-insights',
        name: 'Gather Proposal Insights',
        description: 'Arrange inputs for new proposal',
        category: 'market-intelligence',
        icon: 'search',
        keywords: ['research', 'synthesize', 'citations', 'sources']
      },
      {
        id: 'target-industry-insights',
        name: 'Target Industry Insights',
        description: 'Arrange inputs for new proposal',
        category: 'market-intelligence',
        icon: 'search',
        keywords: ['research', 'synthesize', 'citations', 'sources']
      },
    ];

    [...ddcWorkflows, ...tlWorkflows, ...miWorkflows].forEach(workflow => {
      this.workflows.set(workflow.id, workflow);
    });
  }

  registerWorkflow(workflow: WorkflowConfig): void {
    this.workflows.set(workflow.id, workflow);
  }

  getWorkflow(id: string): WorkflowConfig | undefined {
    return this.workflows.get(id);
  }

  getAllWorkflows(): WorkflowConfig[] {
    return Array.from(this.workflows.values());
  }

  getWorkflowsByCategory(category: 'ddc' | 'thought-leadership' | 'market-intelligence'): WorkflowConfig[] {
    return Array.from(this.workflows.values()).filter(w => w.category === category);
  }

  findWorkflowByKeyword(keyword: string): WorkflowConfig | undefined {
    const lowerKeyword = keyword.toLowerCase();
    return Array.from(this.workflows.values()).find(workflow =>
      workflow.keywords.some(k => lowerKeyword.includes(k) || k.includes(lowerKeyword))
    );
  }
}
